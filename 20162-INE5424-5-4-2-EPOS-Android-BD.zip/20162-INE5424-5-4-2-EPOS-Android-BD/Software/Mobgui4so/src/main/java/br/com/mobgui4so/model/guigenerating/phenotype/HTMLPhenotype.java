/**
 * 
 */
package br.com.mobgui4so.model.guigenerating.phenotype;

/**
 * @author Ercilio Nascimento
 */
public class HTMLPhenotype extends BasePhenotype {

}
