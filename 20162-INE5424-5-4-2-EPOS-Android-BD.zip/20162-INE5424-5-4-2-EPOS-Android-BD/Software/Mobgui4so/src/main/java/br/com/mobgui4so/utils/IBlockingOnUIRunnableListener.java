/**
 * 
 */
package br.com.mobgui4so.utils;

/**
 * @author Ercilio Nascimento
 */
public interface IBlockingOnUIRunnableListener {

	/**
	 * Code to execute on UI thread
	 */
	public void runOnUIThread();

}
