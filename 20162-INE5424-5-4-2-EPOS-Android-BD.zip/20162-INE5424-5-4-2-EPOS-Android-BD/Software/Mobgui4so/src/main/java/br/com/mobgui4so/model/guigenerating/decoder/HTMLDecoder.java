/**
 * 
 */
package br.com.mobgui4so.model.guigenerating.decoder;

import br.com.mobgui4so.model.guigenerating.Genotype;
import br.com.mobgui4so.model.guigenerating.phenotype.BasePhenotype;

/**
 * @author Ercilio Nascimento
 */
public class HTMLDecoder implements IDecodable {

	/* (non-Javadoc)
	 * @see br.com.mobgui4so.model.guigenerating.IDecodable#decode(br.com.mobgui4so.model.guigenerating.Genotype)
	 */
	@Override
	public BasePhenotype decode(Genotype gen, Object context) {
		// TODO Auto-generated method stub
		return null;
	}

}
