# Projeto Final de Sistemas Operacionais II

Este repositório contem o projeto final da disciplina de Sistemas Operacionais II, do curso de Ciências da Computação da UFSC para o semestre 2016/2, ministrada pelo Professor Rafael Luiz Cancian, e baseado no TCC desenvolvido por Ercilio Gonçalves Nascimento.

Este repositório é mantido pelos alunos:

- Emmanuel Podestá Júnior;
- Fernando Jorge Mota;
