## Máquina Virtual

Esta pasta contém os arquivos para criação da máquina virtual do projeto.
