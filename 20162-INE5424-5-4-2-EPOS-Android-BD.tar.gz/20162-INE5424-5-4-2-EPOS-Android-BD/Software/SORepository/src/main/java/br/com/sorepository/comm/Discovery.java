package br.com.sorepository.comm;

import br.com.sorepository.comm.exceptions.InvalidContentException;
import br.com.sorepository.model.dao.ServerDAO;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Created by fernando on 06/12/16.
 */
public class Discovery implements Runnable {
    private SOServerManager manager;
    private boolean running;
    private ServerDAO dao;

    public Discovery() {
        this.manager = SOServerManager.getInstance();
        this.running = true;
    }

    @Override
    public void run() {
        while(this.running) {
            if (this.dao == null) {
                try {
                    dao = new ServerDAO();
                } catch(Exception ex) {
                    continue;
                }
            }
            this.update();
            try {
                Thread.sleep(30 * 1000);
            } catch (InterruptedException e) {
                continue;
            }
        }
    }

    public void stop() {
        this.running = false;
    }

    public void update() {
        System.out.println("Atualizando dados..");
        Map<String, String> servers;
        try {
            servers = dao.getServerUrls();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        for (Map.Entry<String, String> entry: servers.entrySet()) {
            String key = entry.getKey();
            String url = entry.getValue();
            this.updateServer(url, key);
        }
    }

    public void updateServer(String baseUrl, String id) {
        String path = "setRepository.do";
        try {

            String postData = "serverId="+URLEncoder.encode(id, "UTF-8") +
                    "&repositoryUrl="+URLEncoder.encode(manager.getRepositoryUrl(), "UTF-8");

            URI baseUri = new URI(baseUrl);
            URI uri = baseUri.resolve(path);
            System.out.println("POSTing to '"+uri.toString()+"' with data '"+postData+"'");
            URL url = new URL(uri.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            // Add the hmac of the request body..
            System.out.println("Requisicao: '"+manager.getRepositoryUrl()+"|"+id+"'");
            conn.setRequestProperty("so-hmac", manager.encodeContent(manager.getRepositoryUrl()+"|"+id));

            conn.setDoOutput(true);
            conn.setUseCaches(false);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(postData);
            wr.flush();
            // Get the response
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuilder resp = new StringBuilder();
            while ((line = rd.readLine()) != null) {
                resp.append(line);
            }
            String response = resp.toString();
            String h = conn.getHeaderField("so-hmac");
            try {
                manager.validateContent(h, response);
                System.out.println("Validated Server '"+baseUrl+"' responded with: '"+response+"'");
            } catch (InvalidContentException e) {
                System.out.println("Possibly fake Server '"+baseUrl+"' responded with: '"+response+"'");
            }
            wr.close();
            rd.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
