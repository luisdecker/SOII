/**
 *
 */
package br.com.sorepository.model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * @author Ercilio Nascimento
 */
public class InsertDAO extends BaseDAO {

    public InsertDAO() throws ClassNotFoundException, SQLException {
        super();
    }

    public int addParameter(String id, String service_id, String smartobject_id, String register_id, String name, String type, String minvalue, String maxvalue, String options) throws SQLException {
        PreparedStatement prst;
        ResultSet rs;
        prst = conn.prepareStatement("SELECT `id` FROM `parameter` WHERE `service_id`=? AND `smartobject_id`=? AND `name`=?");
        prst.setString(1, service_id);
        prst.setString(2, smartobject_id);
        prst.setString(3, name);
        rs = prst.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        }
        if (id != null) {
            prst = conn.prepareStatement("INSERT INTO  `parameter` (`id`, `service_id`, `smartobject_id`, `register_id`, `name`, `type`, `minvalue`, `maxvalue`, `options`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            prst.setString(1, id);
            prst.setString(2, service_id);
            prst.setString(3, smartobject_id);
            prst.setString(4, register_id);
            prst.setString(5, name);
            prst.setString(6, type);
            prst.setString(7, minvalue);
            prst.setString(8, maxvalue);
            prst.setString(9, options);
        } else {
            prst = conn.prepareStatement("INSERT INTO  `parameter` (`service_id`, `smartobject_id`, `register_id`, `name`, `type`, `minvalue`, `maxvalue`, `options`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            prst.setString(1, service_id);
            prst.setString(2, smartobject_id);
            prst.setString(3, register_id);
            prst.setString(4, name);
            prst.setString(5, type);
            prst.setString(6, minvalue);
            prst.setString(7, maxvalue);
            prst.setString(8, options);
        }

        prst.executeUpdate();
        int result = -1;
        rs = prst.getGeneratedKeys();
        if (id != null) {
            result = Integer.parseInt(id);
        } else if (rs != null && rs.next()) {
            result = rs.getInt(1);
        }
        return result;
    }

    public int addService(String id, String smartobject_id, String name) throws SQLException {
        PreparedStatement prst;
        ResultSet rs;
        prst = conn.prepareStatement("SELECT `id` FROM `service` WHERE `smartobject_id`=? and `name`=?");
        prst.setString(1, smartobject_id);
        prst.setString(2, name);
        rs = prst.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        }
        if (id != null) {
            prst = conn.prepareStatement("INSERT INTO  `service` (`id`, `smartobject_id`, `name`) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            prst.setString(1, id);
            prst.setString(2, smartobject_id);
            prst.setString(3, name);
        } else {
            prst = conn.prepareStatement("INSERT INTO  `service` (`smartobject_id`, `name`) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
            prst.setString(1, smartobject_id);
            prst.setString(2, name);
        }
        prst.executeUpdate();
        int result = -1;
        rs  = prst.getGeneratedKeys();
        if (id != null) {
            result = Integer.parseInt(id);
        } else if (rs != null && rs.next()) {
            result = rs.getInt(1);
        }
        return result;
    }

    public int addSO(String id, String server_id, String device_id, String name) throws SQLException {
        PreparedStatement prst;
        ResultSet rs;
        prst = conn.prepareStatement("SELECT `id` FROM `smartobject` WHERE `name`=?");
        prst.setString(1, name);
        rs = prst.executeQuery();
        if (rs != null && rs.next()) {
            return rs.getInt(1);
        }
        if (id != null) {
            prst = conn.prepareStatement("INSERT INTO  `smartobject` (`id`, `server_id`,`device_id`, `name`) VALUES (?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            prst.setString(1, id);
            prst.setString(2, server_id);
            prst.setString(3, device_id);
            prst.setString(4, name);
        } else {
            prst = conn.prepareStatement("INSERT INTO  `smartobject` (`server_id`,`device_id`, `name`) VALUES (?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
            prst.setString(1, server_id);
            prst.setString(2, device_id);
            prst.setString(3, name);
        }
        int result = -1;
        prst.executeUpdate();
        rs = prst.getGeneratedKeys();
        if (id != null) {
            result = Integer.parseInt(id);
        } else if (rs != null && rs.next()) {
            System.out.println("Detectado id!");
            result = rs.getInt(1);
        }
        if (result != -1) {

            prst = conn.prepareStatement("INSERT INTO  `souserjoin` (`smartobject_id`,`iduser`) SELECT ?, iduser FROM user WHERE type='admin'");
            prst.setInt(1, result);
            prst.executeUpdate();
        }
        return result;
    }

    private void log(String info, StringBuilder sql, Object... params) {
        for (int i = 0; i < params.length; i++) {
            int index = sql.indexOf("?");
            if (params[i] instanceof String) {
                sql = sql.replace(index, ++index, "'" + String.valueOf(params[i]) + "'");
            } else {
                sql = sql.replace(index, ++index, String.valueOf(params[i]));
            }
        }
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        System.out.println(sdf.format(Calendar.getInstance().getTime()) + " " + info + " " + sql.toString());
    }

    private String getConcatValues(ResultSet rs) throws SQLException {
        String s = "";
        for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
            s += rs.getString(i) + ",";
        }
        s = s.substring(0, s.length() - 1);

        return s;
    }
}