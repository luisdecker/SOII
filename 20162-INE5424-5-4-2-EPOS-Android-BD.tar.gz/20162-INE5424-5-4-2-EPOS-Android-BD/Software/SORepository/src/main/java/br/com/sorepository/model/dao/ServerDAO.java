package br.com.sorepository.model.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by fernando on 06/12/16.
 */
public class ServerDAO extends BaseDAO {
    public ServerDAO() throws ClassNotFoundException, SQLException {
        super();
    }

    public Map<String, String> getServerUrls() throws SQLException {
        Map<String, String> results = new HashMap<>();

        PreparedStatement prst;
        ResultSet rs;
        prst = conn.prepareStatement("SELECT id, url FROM `server`");
        rs = prst.executeQuery();
        while (rs.next()) {
            String key = rs.getString(1);
            String url = rs.getString(2);
            results.put(key, url);
        }

        return results;
    }
}
