package br.com.sorepository.comm.exceptions;

/**
 * Created by fernando on 26/11/16.
 */
public class InvalidContentException extends Exception {
}
