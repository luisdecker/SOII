package br.com.sorepository.controller.servlet;

import br.com.sorepository.comm.SOServerManager;
import br.com.sorepository.comm.exceptions.InvalidContentException;
import br.com.sorepository.model.dao.InsertDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @author Ercilio Nascimento
 */
public class ServiceServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public ServiceServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter writer = response.getWriter();



        String id = request.getParameter("id");
        String smartobject_id = request.getParameter("smartobject_id");
        String name = request.getParameter("name");


        try {
            SOServerManager.getInstance().validateContent(request.getHeader("so-hmac"), id+"|"+smartobject_id+"|"+name);
        } catch (InvalidContentException e) {
            response.setStatus(500);
            e.printStackTrace();
            return;
        }

        InsertDAO dao;
        String out;
        try {
            dao = new InsertDAO();
            out = dao.addService(id, smartobject_id, name) + "";


        } catch (Exception e) {
            e.printStackTrace();
            out = "-1";
        }
        response.setHeader("so-hmac", SOServerManager.getInstance().encodeContent(out));
        writer.write(out);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
    }

}
