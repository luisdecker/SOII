package br.com.sorepository.comm;

import br.com.sorepository.comm.exceptions.InvalidContentException;
import org.apache.commons.codec.digest.HmacUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.prefs.Preferences;

/**
 * Created by fernando on 26/11/16.
 */
public class SOServerManager {
    private String key;
    private String repositoryUrl;
    private final String REPOSITORY_URL = "SORepositoryURL";
    private final String KEY_VARIABLE = "SecurityCode";
    private static SOServerManager instance;

    public static SOServerManager getInstance() {
        if (instance == null) {
            instance = new SOServerManager();
        }
        return instance;
    }

    public SOServerManager() {
        Properties p = new Properties();
        try {
            p.load(this.getClass().getClassLoader().getResourceAsStream("javax.usb.properties"));
        } catch (Exception e) {
            e.printStackTrace();
            p = System.getProperties();
        }
        this.repositoryUrl = p.getProperty(REPOSITORY_URL);
        this.key = p.getProperty(KEY_VARIABLE);
    }

    public String getRepositoryUrl() {
        return this.repositoryUrl;
    }

    public String encodeContent(String body) {
        return HmacUtils.hmacSha1Hex(this.key, body);
    }

    public void validateContent(String hash, String body) throws InvalidContentException {
        if (!encodeContent(body).equals(hash)) {
            throw new InvalidContentException();
        }
    }
}
