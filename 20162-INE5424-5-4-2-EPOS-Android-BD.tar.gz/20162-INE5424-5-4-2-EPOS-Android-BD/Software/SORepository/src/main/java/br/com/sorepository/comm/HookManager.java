package br.com.sorepository.comm;

import br.com.sorepository.model.dao.ServerDAO;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.Map;

/**
 * Created by fernando on 14/10/16.
 */
public class HookManager implements ServletContextListener {
    Discovery discovery;
    Thread discoveryThread;
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Booting SORepository..");
        discovery = new Discovery();
        discoveryThread = new Thread(discovery);
        discoveryThread.start();
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Stopping SORepository..");
        discovery.stop();
        while (discoveryThread.isAlive()) {
            try {
                discoveryThread.join();
            } catch (InterruptedException e) {
                continue;
            }
        }
    }
}
