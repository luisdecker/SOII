package br.com.soserver.comm.modbus;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import br.com.soserver.comm.modbus.serialization.Message;
import br.com.soserver.comm.modbus.MessageFactoryTest;
import br.com.soserver.comm.events.ack.AckRead;
import br.com.soserver.comm.events.ack.AckWrite;
import br.com.soserver.comm.events.ack.AckReadSuccess;
import br.com.soserver.comm.events.ack.AckWriteSuccess;
import br.com.soserver.comm.events.ack.AckReadError;
import br.com.soserver.comm.events.ack.AcKWriteError;
import br.com.soserver.comm.events.ack.AckReadErrorType;
import br.com.soserver.comm.events.ack.AckWriteErrorType;


import java.util.List;
import java.util.ArrayList;


public class MessageFactoryTest {
	@Test
	public void writeRegisterTest(){
		MessageFactory msgFactory = new MessageFactory();
		Message msg = new Message();
		Message newMsg = msgFactory.writeRegister(1, 2, 100);
		assertEquals(newMsg.getAddress(),"01");
		assertEquals(newMsg.fromHex(newMsg.getFunctionCode()), 6);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(0, 4)), 2);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(4, 8)), 100);

	}
	@Test
	public void readRegisterTest(){
		MessageFactory msgFactory = new MessageFactory();
		Message msg = new Message();
		Message newMsg = msgFactory.readRegister(1, 2, 10);
		assertEquals(newMsg.getAddress(),"01");
		assertEquals(newMsg.fromHex(newMsg.getFunctionCode()), 3);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(0, 4)), 2);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(4, 8)), 10);

	}
	@Test
	public void fromAckReadSuccessTest(){
		MessageFactory msgFactory = new MessageFactory();
		List<AckRead> acks = new ArrayList<AckRead>();
		AckReadSuccess ackR1 = new AckReadSuccess(1);
		AckReadSuccess ackR2 = new AckReadSuccess(2);
		AckReadSuccess ackR3 = new AckReadSuccess(3);
		AckReadSuccess ackR4 = new AckReadSuccess(4);

		acks.add(ackR1);
		acks.add(ackR2);
		acks.add(ackR3);
		acks.add(ackR4);

		Message msg = new Message();
		msg.setAddress(1);
		msg.setFunctionCode(2);
		Message newMsg = msgFactory.fromAckRead(msg, acks);
		assertEquals(newMsg.getAddress(), msg.getAddress());
		assertEquals(newMsg.getFunctionCode(), msg.getFunctionCode());
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(0,2)), 8);

		assertEquals(newMsg.fromHex(newMsg.getDataSlice(2,6)), 1);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(6,10)), 2);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(10,14)), 3);
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(14,18)), 4);

	}
	@Test
	public void fromAckWriteSuccessTest(){
		MessageFactory msgFactory = new MessageFactory();
		List<AckWrite> acks = new ArrayList<AckWrite>();
		AckWriteSuccess ackW1 = new AckWriteSuccess();
		AckWriteSuccess ackW2 = new AckWriteSuccess();
		AckWriteSuccess ackW3 = new AckWriteSuccess();
		AckWriteSuccess ackW4 = new AckWriteSuccess();

		acks.add(ackW1);

		Message msg = new Message();
		msg.setAddress(1);
		msg.setFunctionCode(2);

		msg.setDataSlice(42, 0, 2);

		Message newMsg = msgFactory.fromAckWrite(msg, acks);
		assertEquals(newMsg.getAddress(), msg.getAddress());
		assertEquals(newMsg.getFunctionCode(), msg.getFunctionCode());
		assertEquals(newMsg.getDataSlice(0,(msg.getData()).length()), msg.getDataSlice(0,(msg.getData()).length()));
	}
	@Test
	public void fromAcksWriteSuccessTest(){
		MessageFactory msgFactory = new MessageFactory();
		List<AckWrite> acks = new ArrayList<AckWrite>();
		AckWriteSuccess ackW1 = new AckWriteSuccess();
		AckWriteSuccess ackW2 = new AckWriteSuccess();
		AckWriteSuccess ackW3 = new AckWriteSuccess();
		AckWriteSuccess ackW4 = new AckWriteSuccess();

		acks.add(ackW1);
		acks.add(ackW2);
		acks.add(ackW3);
		acks.add(ackW4);

		Message msg = new Message();
		msg.setAddress(1);
		msg.setFunctionCode(2);

		msg.setDataSlice(42, 0, 2);
		msg.setDataSlice(42, 2, 4);
		msg.setDataSlice(42, 4, 6);
		msg.setDataSlice(42, 6, 8);

		Message newMsg = msgFactory.fromAckWrite(msg, acks);
		assertEquals(newMsg.getAddress(), msg.getAddress());
		assertEquals(newMsg.getFunctionCode(), msg.getFunctionCode());
		assertEquals(newMsg.getDataSlice(0,8), msg.getDataSlice(0,8));
	}

	@Test
	public void fromAckReadErrorTest(){
		MessageFactory msgFactory = new MessageFactory();
		List<AckRead> acks = new ArrayList<AckRead>();
		AckReadError ackR1 = new AckReadError(AckReadErrorType.ILLEGAL_ADDRESS);
		AckReadSuccess ackR2 = new AckReadSuccess(2);
		AckReadSuccess ackR3 = new AckReadSuccess(3);
		AckReadSuccess ackR4 = new AckReadSuccess(4);

		acks.add(ackR1);
		acks.add(ackR2);
		acks.add(ackR3);
		acks.add(ackR4);

		Message msg = new Message();
		msg.setAddress(1);
		msg.setFunctionCode(2);
		Message newMsg = msgFactory.fromAckRead(msg, acks);
		assertEquals(newMsg.getAddress(), msg.getAddress());
		assertEquals(newMsg.getFunctionCode(), msg.toHex(msg.fromHex(msg.getFunctionCode())+128));
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(0,2)), 2);

	}
	@Test
	public void fromAckWriteErrorTest(){
		MessageFactory msgFactory = new MessageFactory();
		List<AckWrite> acks = new ArrayList<AckWrite>();
		AcKWriteError ackR1 = new AcKWriteError(AckWriteErrorType.ILLEGAL_ADDRESS);
		AckWriteSuccess ackR2 = new AckWriteSuccess();
		AckWriteSuccess ackR3 = new AckWriteSuccess();
		AckWriteSuccess ackR4 = new AckWriteSuccess();

		acks.add(ackR1);
		acks.add(ackR2);
		acks.add(ackR3);
		acks.add(ackR4);

		Message msg = new Message();
		msg.setAddress(1);
		msg.setFunctionCode(2);
		Message newMsg = msgFactory.fromAckWrite(msg, acks);
		assertEquals(newMsg.getAddress(), msg.getAddress());
		assertEquals(newMsg.getFunctionCode(), msg.toHex(msg.fromHex(msg.getFunctionCode())+128));
		assertEquals(newMsg.fromHex(newMsg.getDataSlice(0,2)), 2);

	}

}