import static org.junit.Assert.assertEquals;
import org.junit.Test;
import br.com.soserver.comm.modbus.serialization.Message;
import br.com.soserver.comm.modbus.serialization.Serialization;


public class SerializationTest {
	@Test
	public void SerializationTest(){
		Message msg = new Message();
		msg.setAddress(1);
		msg.setFunctionCode(2);
		msg.setDataSlice(42, 0, 1);
		Serialization ser = new Serialization();
		String result = ser.serialize(msg);
		Message newMsg = ser.deserialize(result);
		String address = newMsg.getAddress();
		String func = newMsg.getFunctionCode();
		String data = newMsg.getData();
		assertEquals(address,"01");
		assertEquals(func, "02");
		assertEquals(data, "2A");
	}
}