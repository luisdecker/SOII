import static org.junit.Assert.assertEquals;
import org.junit.Test;
import br.com.soserver.comm.modbus.serialization.Message;

public class MessageTest {
	@Test
	public void addressTest(){
		Message msg = new Message();
		msg.setAddress(1);
		assertEquals(msg.getAddress(),"01");
	}
	@Test
	public void functionCode(){
		Message msg = new Message();
		msg.setFunctionCode(2);
		assertEquals(msg.getFunctionCode(), "02");
	}
	@Test
	public void dataSlice(){
		Message msg = new Message();
		msg.setDataSlice(42, 0, 1);
		String data = msg.getData();
		assertEquals(data, "2A");
	}
}