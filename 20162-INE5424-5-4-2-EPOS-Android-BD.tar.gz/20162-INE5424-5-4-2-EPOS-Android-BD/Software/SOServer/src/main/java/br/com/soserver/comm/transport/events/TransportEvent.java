package br.com.soserver.comm.transport.events;

/**
 * Created by fernando on 22/11/16.
 */
public class TransportEvent {
    private TransportEventType type;

    public TransportEvent(TransportEventType type) {
        this.type = type;
    }

    public TransportEventType getType() {
        return type;
    }
}
