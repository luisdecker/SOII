package br.com.soserver.comm;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

/**
 * Created by fernando on 14/10/16.
 */
public class HookManager implements ServletContextListener {
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        System.out.println("Booting SOServer..");
        if (ProtocolManagerFactory.isConstructed()) {
            System.out.println("System already booted (??)");
            return;
        }
        try {
            Thread protocolManager = new Thread(ProtocolManagerFactory.getInstance());
            protocolManager.start();
            Discovery.getInstance().start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        System.out.println("Closing SOServer..");
        if (!ProtocolManagerFactory.isConstructed()) {
            return;
        }
        System.out.println("Ok, Really closing SOServer..");
        try {
            Discovery.getInstance().stop();
            ProtocolManagerFactory.getInstance().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
