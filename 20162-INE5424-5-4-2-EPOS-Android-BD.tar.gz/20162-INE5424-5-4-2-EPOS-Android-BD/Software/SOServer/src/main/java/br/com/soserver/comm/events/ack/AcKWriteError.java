package br.com.soserver.comm.events.ack;

/**
 * Created by fernando on 24/11/16.
 */
public class AcKWriteError implements AckWrite {
    private AckWriteErrorType type;

    public AcKWriteError(AckWriteErrorType type) {
        this.type = type;
    }

    public AckWriteErrorType getType() {
        return type;
    }
}
