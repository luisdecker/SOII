package br.com.soserver.comm.exceptions;

public class AckException extends Exception {
    //Parameterless Constructor
    public AckException() {
    }

    //Constructor that accepts a message
    public AckException(String message) {
        super(message);
    }
}
