package br.com.soserver.comm.modbus;

import br.com.soserver.comm.ProtocolManager;
import br.com.soserver.comm.modbus.serialization.Serialization;
import br.com.soserver.comm.transport.Transport;

/**
 * Created by fernando on 23/11/16.
 */
public class ModbusFactory {
    public static ProtocolManager build(int address, Transport transport) {
        Serialization s = new Serialization();
        MessageFactory f = new MessageFactory();
        Communication c = new Communication(address, transport, s);
        return new ModbusManager(f, c);
    }
}
