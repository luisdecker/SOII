package br.com.soserver.comm.events.ack;

/**
 * Created by fernando on 24/11/16.
 */
public class AckReadError implements AckRead {
    private AckReadErrorType type;

    public AckReadError(AckReadErrorType type) {
        this.type = type;
    }

    public AckReadErrorType getType() {
        return type;
    }
}
