package br.com.soserver.comm.events.ack;

/**
 * Created by fernando on 23/11/16.
 */
public interface AckRead {
}
