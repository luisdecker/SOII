package br.com.soserver.comm.transport.events;

/**
 * Created by fernando on 22/11/16.
 */
public enum TransportEventType {
    ERROR,
    DATA_RECEIVED
}
