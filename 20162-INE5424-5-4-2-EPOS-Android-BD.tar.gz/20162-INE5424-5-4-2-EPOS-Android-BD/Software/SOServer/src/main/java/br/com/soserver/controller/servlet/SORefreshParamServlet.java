package br.com.soserver.controller.servlet;

import br.com.soserver.comm.ProtocolManager;
import br.com.soserver.comm.ProtocolManagerFactory;
import br.com.soserver.comm.exceptions.AckException;
import org.apache.commons.lang3.StringEscapeUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;

/**
 * @author Ercilio Nascimento
 */
public class SORefreshParamServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public SORefreshParamServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter writer = response.getWriter();
        ProtocolManager pm;
        try {
            pm = ProtocolManagerFactory.getInstance();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        Map<Integer, Integer> registers;
        int device_id;
        try {
            device_id = Integer.parseInt(request.getParameter("device_id"));
        } catch (NumberFormatException e) {
            return;
        }
        String[] parametersReceived = request.getParameterValues("register_id");
        System.out.println("Parameters received:");
        int nl = 0;
        for (int c = 0, l = parametersReceived.length; c < l; c++) {
            try {
                System.out.println(parametersReceived[c]);
                Integer.parseInt(parametersReceived[c]);
            } catch (NumberFormatException e) {
                continue;
            }
            nl++;
        }
        int[] parameters = new int[nl];
        System.out.println("Registers to read: ");
        for (int c = 0, c2 = 0, l = parametersReceived.length; c < l; c++) {
            try {
                parameters[c2] = Integer.parseInt(parametersReceived[c]);
                System.out.println(parameters[c2]);
                c2++;
            } catch (NumberFormatException e) {
                // Ignore..
            }
        }
        try {
            registers = pm.readRegister(device_id, parameters);
        } catch (AckException e) {
            e.printStackTrace();
            return;
        }

        String out = "";
        for (Map.Entry<Integer, Integer> entry : registers.entrySet()) {
            int key = entry.getKey();
            int values = entry.getValue();
            out += key + "," + values + ";";

        }
        writer.write(StringEscapeUtils.escapeJava(out));

        System.out.println(out);

        writer.write(StringEscapeUtils.escapeJava(out));
    }
}
