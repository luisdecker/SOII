package br.com.soserver.comm;

import br.com.soserver.comm.events.WriteRegisterListener;
import br.com.soserver.comm.events.ack.AcKWriteError;
import br.com.soserver.comm.events.ack.AckWrite;
import br.com.soserver.comm.events.ack.AckWriteErrorType;
import br.com.soserver.comm.events.ack.AckWriteSuccess;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Created by fernando on 08/11/16.
 */
public class Discovery implements WriteRegisterListener {
    private final ExecutorService pool;
    private static Discovery instance;
    private ProtocolManager pm;

    private Discovery(ProtocolManager pm) {
        this.pool = Executors.newFixedThreadPool(4);
        this.pm = pm;
    }

    public static Discovery getInstance() throws Exception {
        if (instance == null) {
            ProtocolManager pm = ProtocolManagerFactory.getInstance();
            instance = new Discovery(pm);
        }
        return instance;
    }

    public void start() {
        pm.onWrite(this);
    }

    public void stop() {
        System.out.println("Shutdown pool..");
        this.pool.shutdown(); // Disable new tasks from being submitted
        try {
            // Wait a while for existing tasks to terminate
            if (!this.pool.awaitTermination(5, TimeUnit.SECONDS)) {
                System.out.println("Cancelling thread..");
                this.pool.shutdownNow(); // Cancel currently executing tasks
                // Wait a while for tasks to respond to being cancelled
                if (!this.pool.awaitTermination(5, TimeUnit.SECONDS)) {
                    System.err.println("Pool did not terminate");
                }
            }
        } catch (InterruptedException ie) {
            // (Re-)Cancel if current thread also interrupted
            System.out.println("Cancelling thread..");
            this.pool.shutdownNow();
            // Preserve interrupt status
            Thread.currentThread().interrupt();
        }
    }


    public AckWrite write(int address, int value) {
        System.out.printf("Recebido mensagem escrevendo valor '%d' no registrador '%d'", value, address);
        if (address != 0) {
            // Only manage one address
            return null;
        }
        DiscoveryNode node;
        try {
            node = new DiscoveryNode(this.pm, value);
        } catch (IOException e) {
            System.out.println("Erro ao identificar URL do SORepository:");
            e.printStackTrace();
            return new AcKWriteError(AckWriteErrorType.BUSY);
        }
        pool.execute(node);
        return new AckWriteSuccess();
    }
}
