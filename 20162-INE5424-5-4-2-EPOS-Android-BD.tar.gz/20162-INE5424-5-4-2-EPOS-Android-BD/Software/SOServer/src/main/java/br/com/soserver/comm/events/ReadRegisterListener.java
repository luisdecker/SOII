package br.com.soserver.comm.events;

import br.com.soserver.comm.events.ack.AckRead;

/**
 * Created by fernando on 23/11/16.
 */
public interface ReadRegisterListener {
    AckRead read(int address);
}
