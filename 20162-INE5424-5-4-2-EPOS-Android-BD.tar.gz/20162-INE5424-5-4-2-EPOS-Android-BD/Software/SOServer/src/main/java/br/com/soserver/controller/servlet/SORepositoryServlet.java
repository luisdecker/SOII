package br.com.soserver.controller.servlet;

import br.com.soserver.comm.SORepositoryManager;
import br.com.soserver.comm.exceptions.InvalidContentException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 * Created by fernando on 26/11/16.
 */
public class SORepositoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        SORepositoryManager manager = SORepositoryManager.getInstance();

        String repositoryUrl = req.getParameter("repositoryUrl");
        String serverId = req.getParameter("serverId");
        System.out.println("Resposta: '"+repositoryUrl+"|"+serverId+"'");


        try {
            manager.validateContent(req.getHeader("so-hmac"), repositoryUrl+"|"+serverId);
        } catch (InvalidContentException e) {
            e.printStackTrace();
            resp.setStatus(500);
            return;
        }

        manager.setRepositoryUrl(repositoryUrl);
        manager.setServerId(serverId);
        String msg = "OK";
        resp.setHeader("so-hmac", manager.encodeContent(msg));
        PrintWriter out = resp.getWriter();
        out.write(msg);
    }
}
