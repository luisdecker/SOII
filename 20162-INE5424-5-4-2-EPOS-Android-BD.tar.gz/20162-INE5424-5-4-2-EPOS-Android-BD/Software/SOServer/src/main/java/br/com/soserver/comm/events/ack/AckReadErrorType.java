package br.com.soserver.comm.events.ack;

/**
 * Created by fernando on 24/11/16.
 */
public enum AckReadErrorType {
    ILLEGAL_FUNCTION,
    ILLEGAL_ADDRESS,
    ILLEGAL_DATA,
    FAILURE,
    BUSY,
    NEGATIVE_ACK
}
