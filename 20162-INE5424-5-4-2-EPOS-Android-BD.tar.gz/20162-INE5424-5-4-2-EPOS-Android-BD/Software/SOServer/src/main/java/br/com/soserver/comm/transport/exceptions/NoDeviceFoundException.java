package br.com.soserver.comm.transport.exceptions;

import java.io.IOException;

/**
 * Created by fernando on 23/11/16.
 */
public class NoDeviceFoundException extends IOException {
    public NoDeviceFoundException(String message) {
        super(message);
    }
}
