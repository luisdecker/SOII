package br.com.soserver.comm.transport;

import br.com.soserver.comm.transport.events.TransportEventListener;

import java.io.BufferedReader;
import java.io.OutputStream;

public interface Transport {
    BufferedReader getInput();

    OutputStream getOutput();

    void addEventListener(TransportEventListener e);

    void removeEventListener(TransportEventListener e);

    void close();
}
