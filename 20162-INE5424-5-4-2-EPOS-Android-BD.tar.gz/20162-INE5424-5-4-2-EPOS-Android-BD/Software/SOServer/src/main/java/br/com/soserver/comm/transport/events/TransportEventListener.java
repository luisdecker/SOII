package br.com.soserver.comm.transport.events;

import java.util.EventListener;

/**
 * Created by fernando on 22/11/16.
 */
public interface TransportEventListener extends EventListener {
    void transportEvent(TransportEvent event);
}
