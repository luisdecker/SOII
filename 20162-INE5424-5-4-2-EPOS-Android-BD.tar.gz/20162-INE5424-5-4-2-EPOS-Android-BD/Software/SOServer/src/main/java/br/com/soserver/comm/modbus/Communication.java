package br.com.soserver.comm.modbus;

import br.com.soserver.comm.modbus.serialization.Message;
import br.com.soserver.comm.modbus.serialization.Serialization;
import br.com.soserver.comm.transport.Transport;
import br.com.soserver.comm.transport.events.TransportEvent;
import br.com.soserver.comm.transport.events.TransportEventListener;
import br.com.soserver.comm.transport.events.TransportEventType;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * Created by fernando on 06/11/16.
 */
public class Communication implements TransportEventListener {
    private BufferedReader input;
    private OutputStream out;
    private Transport transport;
    private int address;
    private List<Integer> sent;
    private Serialization serialization;
    private BlockingQueue<Message> receiveSendQueue;
    private BlockingQueue<Message> receiveQueue;
    private long lastGCrun;

    Communication(int address, Transport transport, Serialization serialization) {
        this.address = address;
        this.transport = transport;
        this.input = transport.getInput();
        this.out = transport.getOutput();
        this.sent = new LinkedList<>();
        this.serialization = serialization;
        this.receiveSendQueue = new LinkedBlockingDeque<>();
        this.receiveQueue = new LinkedBlockingDeque<>();

        transport.addEventListener(this);
    }

    public Message send(Message msg, int retries) {
        Message ack = null;
        int msgAddress = Message.fromHex(msg.getAddress());
        System.out.println("Enviando mensagem para " + msgAddress);
        int msgFunctionCode = Message.fromHex(msg.getFunctionCode());
        synchronized (this.sent) {
            this.sent.add(msgAddress);
        }
        while (ack == null && retries > 0) {
            synchronized (this.out) {
                String toSend = this.serialization.serialize(msg);
                System.out.println("Escrevendo '" + toSend + "' na porta..");
                try {
                    this.out.write(toSend.getBytes());
                } catch (IOException e) {
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e2) {

                    }
                    continue;
                }
            }
            retries--;
            long start = System.currentTimeMillis();
            while (ack == null) {
                long dif = System.currentTimeMillis() - start;
                if (dif > 2000) {
                    break;
                }
                synchronized (this.receiveSendQueue) {
                    try {
                        receiveSendQueue.wait(2000);
                    } catch (InterruptedException e) {
                        continue;
                    }
                    int count = this.receiveSendQueue.size();
                    while (ack == null && count > 0) {
                        ack = this.receiveSendQueue.poll();
                        if (
                                msgAddress != Message.fromHex(ack.getAddress()) ||
                                        (
                                                msgFunctionCode != Message.fromHex(msg.getFunctionCode()) &&
                                                        (msgFunctionCode + 128) != Message.fromHex(msg.getFunctionCode())
                                        )
                                ) {
                            // Probably not what we want, so we just re-add in the query and get a new element
                            this.receiveSendQueue.add(ack);
                            ack = this.receiveSendQueue.poll();
                        }
                        count--;
                    }
                    while (ack == null && count > 0) ;
                }
            }
            retries--;
        }
        synchronized (this.sent) {
            this.sent.remove((Object) msgAddress);
        }
        this.runGC();
        return ack;
    }

    public Message send(Message msg) {
        return send(msg, 1);
    }

    public boolean ack(Message msg) throws IOException {
        int msgAddress = Message.fromHex(msg.getAddress());
        if (msgAddress != this.address) {
            // A message, to be sent to ack, should have the same address of this communication object..
            return false;
        }
        synchronized (this.out) {
            String toSend = this.serialization.serialize(msg);
            this.out.write(toSend.getBytes());
        }
        return true;
    }

    public Message receive() {
        Message result = null;
        while (result == null) {
            try {
                result = this.receiveQueue.take();
            } catch (InterruptedException e) {
                continue;
            }
        }
        return result;
    }

    @Override
    public void transportEvent(TransportEvent event) {
        System.out.println("Evento recebido");
        if (event.getType() != TransportEventType.DATA_RECEIVED) {
            return;
        }
        String line = "";
        try {
            line = input.readLine();
        } catch (Exception e) {
            e.printStackTrace();
            line = "";
        }
        if (line.isEmpty()) {
            System.out.println("Linha esta vazia :(");
            return;
        }
        line += "\r\n"; // We need to re-add because....well, readLine removes that!
        System.out.println("Recebida linha: " + line);
        Message msg = this.serialization.deserialize(line);
        if (msg == null) {
            return;
        }
        int msgAddress = Message.fromHex(msg.getAddress());
        System.out.println("Recebida mensagem de " + msgAddress);
        synchronized (this.sent) {
            if (msgAddress == this.address) {
                this.receiveQueue.add(msg);
            } else if (this.sent.contains(msgAddress)) {
                this.receiveSendQueue.add(msg);
            }
        }
        this.runGC();
    }

    public void runGC() {
        synchronized (this.receiveSendQueue) {
            long now = System.currentTimeMillis();
            long dif = now - this.lastGCrun;
            if (dif < 2000) {
                return;
            }
            this.lastGCrun = now;
            int count = this.receiveSendQueue.size();
            while (count > 0) {
                Message msg = this.receiveSendQueue.poll();
                int msgAddress = Message.fromHex(msg.getAddress());
                if (this.sent.contains(msgAddress)) {
                    this.receiveSendQueue.add(msg);
                }
                count--;
            }
        }
    }

    public void close() {
        this.transport.removeEventListener(this);
        this.transport.close();
    }
}
