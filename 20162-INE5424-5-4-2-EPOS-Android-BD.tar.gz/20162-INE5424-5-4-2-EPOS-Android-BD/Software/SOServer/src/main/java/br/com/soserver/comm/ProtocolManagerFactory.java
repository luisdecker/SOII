package br.com.soserver.comm;

import br.com.soserver.comm.modbus.ModbusFactory;
import br.com.soserver.comm.transport.Transport;
import br.com.soserver.comm.transport.USBTransport;

/**
 * Created by fernando on 23/11/16.
 */
public class ProtocolManagerFactory {
    private static ProtocolManager instance;

    public synchronized static ProtocolManager getInstance() throws Exception {
        if (instance == null) {
            Transport transport = USBTransport.detectTransport();
            instance = ModbusFactory.build(0, transport);
        }
        return instance;
    }

    public synchronized static boolean isConstructed() {
        return instance != null;
    }

}
