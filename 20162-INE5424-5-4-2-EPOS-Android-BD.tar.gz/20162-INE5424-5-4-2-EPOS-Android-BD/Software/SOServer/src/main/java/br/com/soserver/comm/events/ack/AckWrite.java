package br.com.soserver.comm.events.ack;

/**
 * Created by fernando on 24/11/16.
 */
public interface AckWrite {
}
