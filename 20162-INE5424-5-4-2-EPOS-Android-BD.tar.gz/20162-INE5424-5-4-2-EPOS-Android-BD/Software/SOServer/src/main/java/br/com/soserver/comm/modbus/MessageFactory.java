package br.com.soserver.comm.modbus;

import br.com.soserver.comm.events.ack.*;
import br.com.soserver.comm.modbus.serialization.Message;

import java.util.List;


class MessageFactory {
    Message writeRegister(int address, int register, int value) {
        Message msg = new Message();
        msg.setAddress(address);
        msg.setFunctionCode(Message.MessageType.WRITE_SINGLE_REGISTER);
        msg.setDataSlice(register, 0, 4);
        msg.setDataSlice(value, 4, 8);
        return msg;
    }

    // Worth it?
    Message writeRegister(int address, int startingRegister, int[] value) {
        Message msg = new Message();
        msg.setAddress(address);
        msg.setFunctionCode(Message.MessageType.WRITE_MULTIPLE_REGISTERS);
        msg.setDataSlice(startingRegister, 0, 4);
        msg.setDataSlice(value.length, 4, 8);
        msg.setDataSlice(value.length * 2, 8, 10);
        for (int c = 0, start = 10, l = value.length; c < l; c++) {
            msg.setDataSlice(value[c], start, start + 4);
            start += 4;
        }
        return msg;
    }

    Message readRegister(int address, int register, int registerCount) {
        Message msg = new Message();
        msg.setAddress(address);
        msg.setFunctionCode(Message.MessageType.READ_HOLDING_REGISTERS);
        msg.setDataSlice(register, 0, 4);
        msg.setDataSlice(registerCount, 4, 8);
        return msg;
    }


    private Message fromAck(Message orig) {
        Message result = new Message();
        result.setAddress(orig.getAddress());
        return result;
    }

    public Message fromAckRead(Message orig, List<AckRead> acks) {
        Message result = this.fromAck(orig);
        int funCode = Message.fromHex(orig.getFunctionCode());
        result.setFunctionCode(funCode);
        String origFun = result.getFunctionCode();
        if (acks.isEmpty()) {
            // If no method has an opinion about the response, return illegal address
            acks.add(new AckReadError(AckReadErrorType.ILLEGAL_ADDRESS));
        }
        for (AckRead ack : acks) {
            if (ack instanceof AckReadError) {
                result.setFunctionCode(funCode + 128);
                int readErrorCode = 7;
                switch (((AckReadError) ack).getType()) {
                    case ILLEGAL_ADDRESS:
                        readErrorCode = 2;
                        break;
                    case ILLEGAL_FUNCTION:
                        readErrorCode = 1;
                        break;
                    case ILLEGAL_DATA:
                        readErrorCode = 3;
                        break;
                    case NEGATIVE_ACK:
                        readErrorCode = 7;
                        break;
                    case BUSY:
                        readErrorCode = 6;
                        break;
                    case FAILURE:
                        readErrorCode = 4;
                }
                result.setDataSlice(readErrorCode, 0, 2);
                break;
            }
        }
        if (origFun.equals(result.getFunctionCode())) { // Check if there is no errors
            result.setDataSlice(acks.size() * 2, 0, 2); // Byte count
            int start = 2;
            for (AckRead ack : acks) {
                result.setDataSlice(((AckReadSuccess) ack).getData(), start, start + 4);
                start += 4;
            }
        }
        return result;
    }


    public Message fromAckWrite(Message orig, List<AckWrite> acks) {
        Message result = this.fromAck(orig);
        int funCode = Message.fromHex(orig.getFunctionCode());
        result.setFunctionCode(funCode);
        String origFun = result.getFunctionCode();
        if (acks.isEmpty()) {
            // If no method has an opinion about the response, return illegal address
            acks.add(new AcKWriteError(AckWriteErrorType.ILLEGAL_ADDRESS));
        }
        for (AckWrite ack : acks) {
            if (ack instanceof AcKWriteError) {
                result.setFunctionCode(funCode + 128);
                int writeErrorCode = 7;
                switch (((AcKWriteError) ack).getType()) {
                    case ILLEGAL_ADDRESS:
                        writeErrorCode = 2;
                        break;
                    case ILLEGAL_FUNCTION:
                        writeErrorCode = 1;
                        break;
                    case ILLEGAL_DATA:
                        writeErrorCode = 3;
                        break;
                    case NEGATIVE_ACK:
                        writeErrorCode = 7;
                        break;
                    case BUSY:
                        writeErrorCode = 6;
                        break;
                    case FAILURE:
                        writeErrorCode = 4;
                        break;
                }
                result.setDataSlice(writeErrorCode, 0, 2);
                break;
            }
        }
        if (origFun.equals(result.getFunctionCode())) { // Check if there is no errors
            if (acks.size() == 1) {
                String data = orig.getData();
                result.setDataSlice(data, 0, data.length());
            } else {
                result.setDataSlice(orig.getDataSlice(0, 8), 0, 8);
            }
        }
        return result;

    }
}
