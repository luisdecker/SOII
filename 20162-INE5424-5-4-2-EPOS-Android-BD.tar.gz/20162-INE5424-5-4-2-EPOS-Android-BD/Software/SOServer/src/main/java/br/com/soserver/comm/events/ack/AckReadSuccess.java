package br.com.soserver.comm.events.ack;

/**
 * Created by fernando on 24/11/16.
 */
public class AckReadSuccess implements AckRead {
    private int data;

    public AckReadSuccess(int data) {
        this.data = data;
    }

    public int getData() {
        return data;
    }
}
