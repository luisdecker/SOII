package br.com.soserver.comm.events;

import br.com.soserver.comm.events.ack.AckWrite;

/**
 * Created by fernando on 24/11/16.
 */
public interface WriteRegisterListener {
    AckWrite write(int address, int value);
}
