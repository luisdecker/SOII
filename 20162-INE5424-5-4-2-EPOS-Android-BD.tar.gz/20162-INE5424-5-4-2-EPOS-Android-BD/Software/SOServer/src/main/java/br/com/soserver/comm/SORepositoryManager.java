package br.com.soserver.comm;

import br.com.soserver.comm.exceptions.InvalidContentException;
import org.apache.commons.codec.digest.HmacUtils;

import java.io.IOException;
import java.util.Properties;
import java.util.prefs.Preferences;

/**
 * Created by fernando on 26/11/16.
 */
public class SORepositoryManager {
    private String key;
    private final String REPOSITORY_URL = "SORepositoryURL";
    private final String SERVER_ID = "SOServerID";
    private final String KEY_VARIABLE = "SecurityCode";
    private static SORepositoryManager instance;

    public static SORepositoryManager getInstance() {
        if (instance == null) {
            instance = new SORepositoryManager();
        }
        return instance;
    }

    private Preferences getPreferences() {
        return Preferences.userNodeForPackage(this.getClass());
    }

    public SORepositoryManager() {
        String url = getPreferences().get(REPOSITORY_URL, null);
        Properties p = new Properties();
        try {
            p.load(this.getClass().getClassLoader().getResourceAsStream("javax.usb.properties"));
        } catch (Exception e) {
            p = System.getProperties();
        }
        if (url == null) {
            url = p.getProperty(REPOSITORY_URL);
            p.put(REPOSITORY_URL, url);
        }
        this.key = p.getProperty(KEY_VARIABLE);
    }

    public String getRepositoryUrl() {
        return getPreferences().get(REPOSITORY_URL, null);
    }

    public void setRepositoryUrl(String url) {
        Preferences p = getPreferences();
        p.put(REPOSITORY_URL, url);
        try {
            p.flush();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public String getServerId() {
        return getPreferences().get(SERVER_ID, null);
    }

    public void setServerId(String id) {
        Preferences p = getPreferences();
        p.put(SERVER_ID, id);
        try {
            p.flush();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    public String encodeContent(String body) {
        return HmacUtils.hmacSha1Hex(this.key, body);
    }

    public void validateContent(String hash, String body) throws InvalidContentException {
        if (!encodeContent(body).equals(hash)) {
            System.out.println("'"+hash+"' != '"+encodeContent(body)+"'");
            throw new InvalidContentException();
        }
    }
}
