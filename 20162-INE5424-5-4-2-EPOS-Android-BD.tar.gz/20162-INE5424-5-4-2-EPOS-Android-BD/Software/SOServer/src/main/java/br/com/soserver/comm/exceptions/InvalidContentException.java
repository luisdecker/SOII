package br.com.soserver.comm.exceptions;

/**
 * Created by fernando on 26/11/16.
 */
public class InvalidContentException extends Exception {
}
