package br.com.soserver.comm.modbus;

import br.com.soserver.comm.ProtocolManager;
import br.com.soserver.comm.events.ReadRegisterListener;
import br.com.soserver.comm.events.WriteRegisterListener;
import br.com.soserver.comm.events.ack.AcKWriteError;
import br.com.soserver.comm.events.ack.AckRead;
import br.com.soserver.comm.events.ack.AckWrite;
import br.com.soserver.comm.events.ack.AckWriteErrorType;
import br.com.soserver.comm.exceptions.AckException;
import br.com.soserver.comm.modbus.serialization.Message;
import org.apache.commons.lang3.ArrayUtils;

import java.io.IOException;
import java.util.*;


public class ModbusManager implements ProtocolManager {
    private MessageFactory msg_factory;
    private Communication comm;
    private List<ReadRegisterListener> listRead;
    private List<WriteRegisterListener> listWrite;
    private boolean running;

    ModbusManager(MessageFactory msg_factory, Communication comm) {
        this.msg_factory = msg_factory;
        this.comm = comm;
        this.listRead = new ArrayList<>();
        this.listWrite = new ArrayList<>();
        this.running = true;
    }

    @Override
    public void onRead(ReadRegisterListener fptr) {
        this.listRead.add(fptr);
    }

    @Override
    public void onWrite(WriteRegisterListener fptr) {
        this.listWrite.add(fptr);
    }

    public int writeRegister(int address, Map<Integer, Integer> parameters) {
        int successCount = 0;
        int pl = parameters.size();
        Integer[] parametersKeys = new Integer[pl];
        for(Integer key: parameters.keySet()) {
            parametersKeys[--pl] = key;
        }
        Arrays.sort(parametersKeys);
        int[][] newParametersKeys = new int[parametersKeys.length][2];
        int nl = 0;
        for (int c = 0, l = parametersKeys.length; c < l; ) {
            System.out.printf("Managing register %d\n", parametersKeys[c]);
            int toAdd = 1;
            for (; c + toAdd < l && toAdd < 50 && parametersKeys[c] + toAdd == parametersKeys[c + toAdd]; toAdd++) ;
            newParametersKeys[nl][0] = parametersKeys[c];
            newParametersKeys[nl][1] = toAdd;
            nl++;
            c += toAdd;
        }

        for (int c = 0; c < nl; c++) {
            int key = newParametersKeys[c][0];
            int l = newParametersKeys[c][1];
            System.out.printf("Starting address: %d - Write %d registers\n", key, l);
            int[] values = new int[l];
            for (int c2 = 0; c2 < l; c2++) {
                values[c2] = parameters.get(key + c2);
            }
            String concatenatedValue = "";
            for (Integer value : values) {
                concatenatedValue += value + ", ";
            }
            System.out.printf(
                    "Enviando mensagem para %s: Alterando registrador %s com valor %s\n",
                    address,
                    key,
                    concatenatedValue
            );
            Message msg;
            if (l == 1) {
                msg = msg_factory.writeRegister(address, key, values[0]);
            } else {
                msg = msg_factory.writeRegister(address, key, values);
            }
            Message ack = comm.send(msg);
            if (ack != null) {
                System.out.println("Recebido ack!");
                System.out.println(ack.getFunctionCode());
            }
            if (ack != null &&
                    Message.fromHex(ack.getFunctionCode()) == Message.fromHex(msg.getFunctionCode())) {
                System.out.println("Sucesso! Incrementando successCount com "+l);
                successCount += l;
            }
        }
        return successCount;
    }

    @Override
    public int writeRegister(int address, int register, int value) {
        Map<Integer, Integer> reg = new HashMap<>();
        reg.put(register, value);
        return writeRegister(address, reg);
    }

    @Override
    public int readRegister(int address, int register) throws AckException {
        int[] registers = {register};
        return readRegister(address, registers).get(register);
    }

    @Override
    public int[] readRegister(int address, int startingRegister, int count) throws AckException {
        if (count < 1) {
            return new int[0];
        }
        int[] registers = new int[count];
        for (int c = 0; c < count; c++) {
            System.out.printf("Want to read register %d\n", startingRegister+c);
            registers[c] = startingRegister + c;
        }
        // Probably will batch everything in one command
        Map<Integer, Integer> values = readRegister(address, registers);
        int[] results = new int[count];
        for (int c = 0; c < count; c++) {
            results[c] = values.get(startingRegister + c);
        }
        return results;
    }

    public Map<Integer, Integer> readRegister(int address, int[] parameters) throws AckException {
        Map<Integer, Integer> registers = new HashMap<>();
        Arrays.sort(parameters);
        int nl = 0;
        int[][] newParameters = new int[parameters.length][2];
        for (int c = 0, l = parameters.length; c < l; ) {
            int toAdd = 1;
            for (; c + toAdd < l && toAdd < 50 && parameters[c] + toAdd == parameters[c + toAdd]; toAdd++) ;
            newParameters[nl][0] = parameters[c];
            newParameters[nl][1] = toAdd;
            nl++;
            c += toAdd;
        }
        for (int c = 0; c < nl; c++) {
            int[] param = newParameters[c];
            System.out.printf("Starting address: %d - Read %d registers\n", param[0], param[1]);

            Message msg = this.msg_factory.readRegister(address, param[0], param[1]);
            Message ack = comm.send(msg);
            if (ack == null ||
                    Message.fromHex(ack.getFunctionCode()) == (128 + Message.fromHex(msg.getFunctionCode()))) {
                // System.out.println("Excecao detectada :(");
                // continue;
                // Make an exception an exit the system.
                throw new AckException();
            }
            // Byte count
            int count = Message.fromHex(ack.getDataSlice(0, 2));
            if (count == param[1] * 2) {
                int start = 2;
                for (int regAddress = param[0], regEnd = regAddress + param[1]; regAddress < regEnd; regAddress++) {
                    int value = Message.fromHex(ack.getDataSlice(start, start + 4));
                    System.out.printf("valor do registrador %d = %d\n", regAddress, value);
                    registers.put(regAddress, value);
                    start += 4;
                }
            }
        }
        return registers;
    }

    @Override
    public void run() {
        while (this.running) {
            Message msg = this.comm.receive();
            int functionCode = Message.fromHex(msg.getFunctionCode());
            Message msgAck = null;
            if (functionCode == Message.MessageType.READ_HOLDING_REGISTERS.hexa) {
                int startingAddress = Message.fromHex(msg.getDataSlice(0, 4));
                int quantity = Message.fromHex(msg.getDataSlice(4, 8));
                List<ReadRegisterListener> readRegisters = this.listRead;
                List<AckRead> acks = new ArrayList<>();
                for (int address = startingAddress, l = startingAddress + quantity; address < l; address++) {
                    AckRead ack = null;
                    for (ReadRegisterListener readRegister : readRegisters) {
                        ack = readRegister.read(address);
                        if (ack != null) {
                            break;
                        }
                    }
                    if (ack != null) {
                        acks.add(ack);
                    }
                }
                msgAck = this.msg_factory.fromAckRead(msg, acks);
            } else if (functionCode == Message.MessageType.WRITE_SINGLE_REGISTER.hexa ||
                    functionCode == Message.MessageType.WRITE_MULTIPLE_REGISTERS.hexa) {
                List<AckWrite> acks = new ArrayList<>();
                int startingAddress = Message.fromHex(msg.getDataSlice(0, 4));
                int quantity = 1;
                int dataStart = 4;
                List<WriteRegisterListener> writeRegisters = this.listWrite;
                if (functionCode == Message.MessageType.WRITE_MULTIPLE_REGISTERS.hexa) {
                    quantity = Message.fromHex(msg.getDataSlice(4, 8));
                    int byteCount = Message.fromHex(msg.getDataSlice(8, 10));
                    if (byteCount != quantity * 2) {
                        // Add error related to acks error data
                        acks.add(new AcKWriteError(AckWriteErrorType.ILLEGAL_DATA));
                    }
                    // set new data start location..
                    dataStart = 10;
                }
                for (int address = startingAddress, l = startingAddress + quantity; address < l; address++) {
                    AckWrite ack = null;
                    int value = Message.fromHex(msg.getDataSlice(dataStart, dataStart + 4));
                    dataStart += 4;
                    for (WriteRegisterListener writeRegister : writeRegisters) {
                        ack = writeRegister.write(address, value);
                        if (ack != null) {
                            break;
                        }
                    }
                    if (ack != null) {
                        acks.add(ack);
                    }
                }
                msgAck = this.msg_factory.fromAckWrite(msg, acks);
            }
            try {
                this.comm.ack(msgAck);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void close() {
        this.running = false;
        this.comm.close();
    }

}
