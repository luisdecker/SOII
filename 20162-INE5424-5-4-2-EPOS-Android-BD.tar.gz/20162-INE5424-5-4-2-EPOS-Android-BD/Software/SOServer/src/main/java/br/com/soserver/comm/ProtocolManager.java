package br.com.soserver.comm;

import br.com.soserver.comm.events.ReadRegisterListener;
import br.com.soserver.comm.events.WriteRegisterListener;
import br.com.soserver.comm.exceptions.AckException;

import java.util.Map;

/**
 * Created by fernando on 21/11/16.
 */
public interface ProtocolManager extends Runnable {
    int writeRegister(int address, int register, int value);

    int writeRegister(int address, Map<Integer, Integer> parameters);

    Map<Integer, Integer> readRegister(int address, int[] registers) throws AckException;

    int readRegister(int address, int register) throws AckException;

    int[] readRegister(int address, int startingRegister, int count) throws AckException;

    void onRead(ReadRegisterListener fptr);

    void onWrite(WriteRegisterListener fptr);

    void close();
}
