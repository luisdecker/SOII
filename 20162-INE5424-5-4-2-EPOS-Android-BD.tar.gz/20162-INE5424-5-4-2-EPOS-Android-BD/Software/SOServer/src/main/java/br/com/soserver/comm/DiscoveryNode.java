package br.com.soserver.comm;

import br.com.soserver.comm.exceptions.AckException;
import br.com.soserver.comm.exceptions.InvalidContentException;
import org.apache.commons.lang3.StringUtils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.*;

/**
 * Created by fernando on 08/11/16.
 */
class DiscoveryNode implements Runnable {
    private ProtocolManager pm;
    private int address;
    private StringBuilder s;
    private boolean run;
    private SORepositoryManager manager;

    DiscoveryNode(ProtocolManager pm, int address) throws IOException {
        this.pm = pm;
        this.address = address;
        this.s = new StringBuilder();
        this.manager = SORepositoryManager.getInstance();
        this.run = true;
    }

    public void stop() {
        this.run = false;
    }

    @Override
    public void run() {
        int page = 0;
        int pagingAddress = 10000 - 50;
        int pageSize = 30;
        int errorCount = 0;
        while (this.run && errorCount < 10) {
            int pack = this.pm.writeRegister(this.address, pagingAddress, page);
            if (pack == 0) {
                errorCount++;
                continue;
            }
            int[] results;
            try {
                results = this.pm.readRegister(this.address, pagingAddress, pageSize);
            } catch (AckException e) {
                e.printStackTrace();
                errorCount++;
                continue;
            }
            int pageCheck = results[0];
            if (pageCheck != page) {
                // The page is not the same! Should just continue processing..
                errorCount++;
                continue;
            }
            int zeroCount = 0;
            for (int i = 1; i < pageSize; i++) {
                if (results[i] == 0) {
                    // If a null character is detected, stop the machines!
                    zeroCount++;
                    continue;
                }
                this.s.append((char) results[i]);
            }
            if (pageSize-1 == zeroCount) {
                this.run = false;
            }
            page++;
            errorCount = 0;
        }
        String response = this.s.toString();
        System.out.println(response);
        List<String> rows = Arrays.asList(response.split(";"));
        int c = 0;
        int smartObjectId = -1;
        int serviceId = -1;
        for (String row : rows) {
            row = row+",check";
            System.out.println("Linha: '"+row+"'");
            List<String> data = Arrays.asList(row.split(","));
            Map<String, String> postData = new HashMap<>();
            if (c == 0 && data.size() == 2 && smartObjectId == -1) {
                String name = data.get(0);
                if (!"check".equals(data.get(1))) {
                    System.out.println("Checksum nao bateu quando administrando Smartobject. Ignorando");
                    continue;
                }
                postData.put("name", name);
                postData.put("server_id", manager.getServerId());
                postData.put("device_id", this.address + "");
                // Insert smart object into the database
                smartObjectId = sendToRepository("SmartObject.do", postData, null+"|"+manager.getServerId()+"|"+this.address+"|"+name);
            } else if (data.size() == 2 && smartObjectId != -1) {
                String name = data.get(0);
                if (!"check".equals(data.get(1))) {
                    System.out.println("Checksum nao bateu quando administrando Servico. Ignorando");
                    continue;
                }
                postData.put("name", name);
                postData.put("smartobject_id", smartObjectId + "");
                // Insert service into the database
                serviceId = sendToRepository("Service.do", postData, null+"|"+smartObjectId+"|"+name);
            } else if (data.size() == 7 && smartObjectId != -1 && serviceId != -1) {
                // Insert parameter
                String name = data.get(0);
                String register_id = data.get(1);
                String type = data.get(2);
                String minValue = data.get(3);
                String maxValue = data.get(4);
                String options = data.get(5);
                if (!"check".equals(data.get(6))) {
                    System.out.println("Checksum nao bateu quando administrando Parametro. Ignorando");
                    continue;
                }
                postData.put("service_id", serviceId + "");
                postData.put("smartobject_id", smartObjectId+"");
                postData.put("register_id", register_id);
                postData.put("name", name);
                postData.put("type", type);
                if (!minValue.isEmpty()) {
                    postData.put("minvalue", minValue);
                }
                if(!maxValue.isEmpty()) {
                    postData.put("maxvalue", maxValue);
                }
                if(!options.isEmpty()) {
                    postData.put("options", options);
                }
                System.out.println("Cliente: '"+postData.get("id")+"|"+postData.get("service_id")+"|"+postData.get("smartobject_id")+"|"+postData.get("register_id")+"|"+postData.get("name")+"|"+postData.get("type")+"|"+postData.get("minvalue")+"|"+postData.get("maxvalue")+"|"+postData.get("options")+"'");
                sendToRepository("Parameter.do", postData, postData.get("id")+"|"+postData.get("service_id")+"|"+postData.get("smartobject_id")+"|"+postData.get("register_id")+"|"+postData.get("name")+"|"+postData.get("type")+"|"+postData.get("minvalue")+"|"+postData.get("maxvalue")+"|"+postData.get("options"));
            }
            c++;
        }
    }

    protected int sendToRepository(String path, Map<String, String> data, String body) {

        String baseUrl = manager.getRepositoryUrl();

        try {

            List<String> postEntries = new ArrayList<>();
            for (Map.Entry<String, String> entry : data.entrySet()) {
                postEntries.add(URLEncoder.encode(entry.getKey(), "UTF-8") + "=" + URLEncoder.encode(entry.getValue(), "UTF-8"));
            }
            String postData = StringUtils.join(postEntries, "&");

            URI baseUri = new URI(baseUrl);
            URI uri = baseUri.resolve(path);
            System.out.println("POSTing to '"+uri.toString()+"' with data '"+postData+"'");
            URL url = new URL(uri.toString());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            // Add the hmac of the request body..
            conn.setRequestProperty("so-hmac", manager.encodeContent(body));

            conn.setDoOutput(true);
            conn.setUseCaches(false);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(postData);
            wr.flush();

            // Get the response
            BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            StringBuilder resp = new StringBuilder();
            while ((line = rd.readLine()) != null) {
                resp.append(line);
            }
            wr.close();
            rd.close();

            String response = resp.toString();
            String h = conn.getHeaderField("so-hmac");
            try {
                manager.validateContent(h, response);
                System.out.println("Validated Server '"+baseUrl+"' responded with: '"+response+"'");
            } catch (InvalidContentException e) {
                System.out.println("Possibly fake Server '"+baseUrl+"' responded with: '"+response+"'");
            }
            return Integer.parseInt(response);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }
}
