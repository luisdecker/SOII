#ifdef SIMULATE
#include <thread>
#include <iostream>
using std::endl;
using std::cout;
#else
#include <uart.h>
#include <thread.h>
#include <utility/ostream.h>
using EPOS::endl;
EPOS::OStream cout;
#endif
#include "comm/transport/serial/serial.h"
#include "comm/transport/transport.h"
#include "comm/modbus/modbus_factory.cc"
#include "comm/read.h"
#include "comm/write.h"
#include "comm/api.cc"
#include "comm/objects/smartobject.cc"
#include "comm/objects/service.cc"
#include "comm/objects/parameter_double.cc"
#include "comm/objects/parameter_boolean.cc"
#include "comm/objects/parameter_combo.cc"
#include "comm/objects/parameter_get.cc"



int temperature;
int poweredOn;
int humidity;
int speed;
int timer;
int function;

class val : public WriteInterface, public ReadInterface {
private:
    int value;
    const char* label;
public:
    val(const char* label) {
        this->label = label;
        this->value = 0;
    }
    val(const char* label, int value) {
        this->label = label;
        this->value = value;
    }
    bool write(int val) {
        cout << "Updating parameter '" << this->label << "' with value '" << val << "'" << endl;
        this->value = val;
        return true;
    }
    int read() {
        cout << "Reading parameter '" << this->label << "' with value detected '" << value << "'" << endl;
        return this->value;
    }
};

int thread1(Communication *comm) {
    comm->run();
    return 0;
}
int thread2(Communication *comm) {
    comm->runGC();
    return 0;
}
int main(int argc, char** argv) {
    TransportInterface* transport = new SerialTransport();

    #ifdef SIMULATE
    transport->setPort("/dev/pts/6");
    #else
    transport->setPort(new PC_UART(115200, 8, 0, 1, 1));
    #endif
    Communication *comm = ModbusFactory::buildCommunication(161, transport);
    ProtocolManager *manager = ModbusFactory::build(comm);
    CommAPI *api = new CommAPI(manager);
    api->start();

    SmartObject *object = new SmartObject("Geladeira");
    Service *geladeira = new Service("Geladeira");
    Service *congelador = new Service("Congelador");
    object->addService(geladeira);
    object->addService(congelador);

    ParameterType *temperatura = new ParameterDouble("1", "5");
    ParameterType *temperaturaAtual = new ParameterGet();
    ParameterType *ligado = new ParameterBoolean();
    ParameterCombo *gelo = new ParameterCombo();
    gelo->addOption("Pouco");
    gelo->addOption("Médio");
    gelo->addOption("Muito");
    gelo->addOption("Inteligente");


    Parameter *ligadoGeladeira = new Parameter("Ligado", "1", ligado);
    Parameter *temperaturaGeladeira = new Parameter("Temperatura", "2", temperatura);
    Parameter *temperaturaAtualGeladeira = new Parameter("Temperatura Atual", "6", temperaturaAtual);


    Parameter *ligadoCongelador = new Parameter("Ligado", "3", ligado);
    Parameter *temperaturaCongelador = new Parameter("Temperatura", "4", temperatura);
    Parameter *temperaturaAtualCongelador = new Parameter("Temperatura Atual", "5", temperaturaAtual);
    Parameter *geloCongelador = new Parameter("Gelo", "7", gelo);

    geladeira->addParameter(ligadoGeladeira);
    geladeira->addParameter(temperaturaGeladeira);
    geladeira->addParameter(temperaturaAtualGeladeira);
    //
    congelador->addParameter(ligadoCongelador);
    congelador->addParameter(temperaturaCongelador);
    congelador->addParameter(temperaturaAtualCongelador);
    congelador->addParameter(geloCongelador);

    cout << object->toString() << endl;


    #ifdef SIMULATE
    std::thread *t1 = new std::thread(thread1, comm);
    std::thread *t2 = new std::thread(thread2, comm);
    #else
    EPOS::Thread *t1 = new EPOS::Thread(&thread1, comm);
    EPOS::Thread *t2 = new EPOS::Thread(&thread2, comm);
    #endif
    // After start the threads...
    api->insert(object);
    manager->run();
    t1->join();
    t2->join();
};
