#ifndef SLEEP_INTERFACE
#define SLEEP_INTERFACE

void delay(unsigned int d);

#endif
