#include "sleep_app.cc"

int main(void) {
    delay(2000000);
    return 0;
}
