#ifndef SERIAL_H
#define SERIAL_H

#ifdef SIMULATE
#include "libc.h"
#else
#include "epos.h"
#endif

class SerialTransport : public EAB::SerialTransport {};

#endif
