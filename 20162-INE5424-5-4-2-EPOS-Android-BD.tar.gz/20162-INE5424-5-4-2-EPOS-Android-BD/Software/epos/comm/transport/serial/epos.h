#ifndef EPOS_SERIAL_TRANSPORT
#define EPOS_SERIAL_TRANSPORT

#include "../transport.h"
#include <uart.h>
#include <utility/string.h>
#include "../../utilities/mutex.h"
#include "../../utilities/mutex_app.cc"
namespace EAB {
class SerialTransport : public TransportInterface {
public:
    SerialTransport() {
        this->readMutex = new MutexApp();
        this->writeMutex = new MutexApp();
    }
    ~SerialTransport() {
        if (this->uart != 0) {
            delete uart;
        }
        delete this->readMutex;
        delete this->writeMutex;
    }
    SerialTransport(const char *port) {
        this->setPort(port);
    }
    SerialTransport(const int port) {
        this->setPort(port);
    }
    SerialTransport(EPOS::PC_UART *uart) {
        this->setPort(uart);
    }

    const char *read() {
        this->readMutex->lock();
        int length = 8;
        int count = 0;
        char *result = new char[length];
        memset(result, '\0', length);
        char lastchar = '\0';
        while (lastchar != '\n') {
            // Stop just when '\n' is received, as getline
            lastchar = this->uart->get();
            count++;
            if (count >= length) {
                length *= 2;
                char *tmp = new char[length];
                memset(tmp, '\0', length);
                strcpy(tmp, result);
                delete[] result;
                result = tmp;
            }
            char *a = new char[2];
            memset(a, '\0', 2);
            a[0] = lastchar;
            strcat(result, a);
            delete[] a;
        }
        this->readMutex->unlock();
        return result;
    }

    void write(const char *command) {
        this->writeMutex->lock();
        int l = strlen(command);
        for (int c = 0; c < l; c++) {
            this->uart->put(command[c]);
        }
        this->writeMutex->unlock();
    }

    void setPort(const char *port) {
        setPort(atoi(port));
    }

    void setPort(const int port) {
        EPOS::PC_UART *uart = new EPOS::PC_UART(port);
        setPort(uart);
    }

    void setPort(EPOS::PC_UART *uart) {
        this->uart = uart;
    }

protected:
    EPOS::PC_UART *uart;
    MutexInterface *readMutex;
    MutexInterface *writeMutex;
};
}

#endif
