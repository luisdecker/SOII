#ifndef LIBC_SERIAL_TRANSPORT
#define LIBC_SERIAL_TRANSPORT

#include <fstream>

#include <string.h>
#include <string>

#include "../transport.h"
#include "../../utilities/mutex.h"
#include "../../utilities/mutex_app.cc"
namespace EAB {
class SerialTransport : public TransportInterface {
public:
    SerialTransport() {
        this->readMutex = new MutexApp();
        this->writeMutex = new MutexApp();

    }
    ~SerialTransport() {
        delete this->readMutex;
        delete this->writeMutex;
    }
    SerialTransport(const char *port) {
        this->setPort(port);
    }
    SerialTransport(const int port) {
        this->setPort(port);
    }

    const char *read() {
        this->readMutex->lock();
        std::ifstream usb(this->port);
        int length = 8;
        int count = 0;
        char *result = new char[length];
        memset(result, '\0', length);
        char lastchar = '\0';
        while (lastchar != '\n' && usb.is_open()) {
            // Stop just when '\n' is received, as getline
            lastchar = usb.get();
            count++;
            if (count >= length) {
                length *= 2;
                char *tmp = new char[length];
                memset(tmp, '\0', length);
                strcpy(tmp, result);
                delete[] result;
                result = tmp;
            }
            char *a = new char[2];
            memset(a, '\0', 2);
            a[0] = lastchar;
            strcat(result, a);
            delete[] a;
        }
        this->readMutex->unlock();
        return result;
    }

    void write(const char *command) {
        this->writeMutex->lock();

        std::ofstream usb(this->port);
        if (usb.is_open()) {
            usb << command << "\n";
            usb.close();
        }
        this->writeMutex->unlock();
    }

    void setPort(const char *port) {
        this->port = port;
    }

    void setPort(const int portId) {
        char *port = new char[22];
        char *n = new char[10];
        sprintf(n, "%d", portId);
        strcat(port, "/dev/ttyUSB");
        strcat(port, n);
        delete[] n;
        setPort(port);
    }

protected:
    const char *port;
    MutexInterface *readMutex;
    MutexInterface *writeMutex;

};
}

#endif
