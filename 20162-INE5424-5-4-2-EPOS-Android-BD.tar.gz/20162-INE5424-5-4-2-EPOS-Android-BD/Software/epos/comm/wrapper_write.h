#ifndef WRAPPER_WRITE_H
#define WRAPPER_WRITE_H

#include "write.h"

class WrapperWrite : public WriteInterface {
    typedef bool (*fW)(int);
private:
    fW func;

public:
    WrapperWrite(bool (*fptr)(int));

    bool write(int val);
};


#endif
