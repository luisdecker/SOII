#ifndef READ_H
#define READ_H

class ReadInterface {
public:
    virtual int read() = 0;
};

#endif
