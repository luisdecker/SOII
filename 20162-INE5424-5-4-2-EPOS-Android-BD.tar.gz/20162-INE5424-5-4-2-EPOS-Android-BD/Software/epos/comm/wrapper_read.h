#ifndef WRAPPER_READ_H
#define WRAPPER_READ_H

#include "read.h"

class WrapperRead : public ReadInterface {
    typedef int (*fR)();

private:
    fR func;

public:
    WrapperRead(int (*fptr)());
    int read();
};

#endif
