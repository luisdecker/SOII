#ifndef COMMAPI_CC
#define COMMAPI_CC
#include "api.h"
#include "utilities/function.cc"
#include "utilities/list_app.cc"
#include "utilities/mutex_app.cc"
#include "wrapper_write.cc"
#include "wrapper_read.cc"
#include "read.h"
#include "write.h"
#include "pagination.cc"


CommAPI::CommAPI(ProtocolManager *pm) {
    this->pm = pm;
    this->pagination = 0;
    this->listRead = new ListApp<EAB::Function<ReadInterface*>>();
    this->listWrite = new ListApp<EAB::Function<WriteInterface*>>();
    this->mutexRead = new MutexApp();
    this->mutexWrite = new MutexApp();
}

CommAPI::~CommAPI() {
    delete this->listRead;
    delete this->listWrite;
    delete this->mutexRead;
    delete this->mutexWrite;
}

void CommAPI::start() {
    this->pm->setReadHandler(this);
    this->pm->setWriteHandler(this);

}

void CommAPI::setReadHandler(int address, ReadInterface *fptr) {
    this->mutexRead->lock();
    EAB::Function<ReadInterface *> readHandler(address, fptr);
    EAB::Function<ReadInterface *> rH = listRead->search(readHandler);
    if (readHandler == rH) {
        this->listRead->remove(rH);
    }
    this->listRead->insert(readHandler);
    this->mutexRead->unlock();
}

void CommAPI::setReadHandler(int address, int (*fptr)()) {
    setReadHandler(address, new WrapperRead(fptr));
}

void CommAPI::setWriteHandler(int address, WriteInterface *fptr) {
    this->mutexWrite->lock();
    EAB::Function<WriteInterface *> writeHandler(address, fptr);
    EAB::Function<WriteInterface *> wH = this->listWrite->search(writeHandler);
    if (writeHandler == wH) {
        this->listWrite->remove(wH);
    }
    this->listWrite->insert(writeHandler);
    this->mutexWrite->unlock();
}

void CommAPI::setWriteHandler(int address, bool (*fptr)(int)) {
    setWriteHandler(address, new WrapperWrite(fptr));
}

AckRead* CommAPI::read(int regAddress) {
    EAB::Function<ReadInterface *> f(regAddress);
    this->mutexRead->lock();
    EAB::Function<ReadInterface *> r = listRead->search(f);
    this->mutexRead->unlock();
    ReadInterface *func = r.getFunction();
    if (r.getAddress() != regAddress || func == 0) {
        return 0;
    }
    int result = func->read();
    return new AckReadSuccess(result);
}

AckWrite* CommAPI::write(int regAddress, int value) {
    EAB::Function<WriteInterface *> f(regAddress);
    this->mutexWrite->lock();
    EAB::Function<WriteInterface *> w = listWrite->search(f);
    this->mutexWrite->unlock();
    WriteInterface *func = w.getFunction();
    bool result = false;
    if (w.getAddress() == regAddress && func != 0) {
        // There's a function to process the request! \o/
        result = func->write(value);
    }
    if (!result) {
        return 0;
    }
    return new AckWriteSuccess();
}

void CommAPI::insert(SmartObject *object) {
    if (this->pagination != 0) {
        return;
    }
    const char* data = object->toString();
    this->pagination = new Pagination(data, 10000-50, 30);
    this->pm->setReadHandler(this->pagination);
    this->pm->setWriteHandler(this->pagination);
    this->pm->writeRegister(0, 0, this->pm->getAddress());
}
#endif
