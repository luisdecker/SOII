#ifndef COMMAPI_H
#define COMMAPI_H
#include "events/ack/ack_read_error.h"
#include "events/ack/ack_read_success.h"
#include "events/ack/ack_write_error.h"
#include "events/ack/ack_write_success.h"
#include "events/read_register.h"
#include "utilities/function.h"
#include "utilities/list.h"
#include "utilities/mutex.h"
#include "events/write_register.h"
#include "read.h"
#include "write.h"
#include "pagination.h"
#include "objects/smartobject.h"
#include "protocol_manager.h"


class CommAPI : public ReadRegisterInterface, public WriteRegisterInterface {
public:
    CommAPI(ProtocolManager *pm);
    ~CommAPI();
    void start();
    void setReadHandler(int address, int (*fptr)());
    void setReadHandler(int address, ReadInterface *fptr);
    void setWriteHandler(int address, bool (*fptr)(int));
    void setWriteHandler(int address, WriteInterface *fptr);
    void insert(SmartObject *object);
    AckRead* read(int regAddress);
    AckWrite* write(int regAddress, int value);

private:
    ProtocolManager *pm;
    Pagination *pagination;
    MutexInterface *mutexRead;
    MutexInterface *mutexWrite;

    const char* data;
    ListInterface<EAB::Function<ReadInterface *>> *listRead;
    ListInterface<EAB::Function<WriteInterface *>> *listWrite;
};
#endif
