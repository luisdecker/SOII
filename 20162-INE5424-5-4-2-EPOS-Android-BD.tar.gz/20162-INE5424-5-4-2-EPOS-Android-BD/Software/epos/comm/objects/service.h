#ifndef SERVICE_H
#define SERVICE_H

#include "parameter.h"
#include "../utilities/list.h"


class Service {
public:
    Service(const char *name);

    /** Getters */
    const char* getName();
    const ListInterface<Parameter*>* getParameters();

    /** Setters */
    void setName(const char* name);
    void addParameter(Parameter* parameter);

    /** Dumper **/
    const char* toString();
protected:
    const char *name;
    ListInterface<Parameter*> *parameters;
};

#endif
