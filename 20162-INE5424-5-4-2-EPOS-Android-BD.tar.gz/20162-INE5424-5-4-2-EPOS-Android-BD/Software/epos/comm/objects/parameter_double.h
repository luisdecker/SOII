#ifndef PARAMETER_DOUBLE_H
#define PARAMETER_DOUBLE_H

#include "parameter_type.h"
class ParameterDouble : public ParameterType {
public:
    ParameterDouble(const char* min, const char* max);
    const char* getType();
    const char* getMinValue();
    const char* getMaxValue();
    const char* getOptions();
protected:
    const char *min;
    const char *max;
};

#endif
