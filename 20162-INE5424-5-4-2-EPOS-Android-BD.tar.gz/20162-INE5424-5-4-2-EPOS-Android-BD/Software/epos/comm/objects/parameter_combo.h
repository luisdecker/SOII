#ifndef PARAMETER_COMBO_H
#define PARAMETER_COMBO_H

#include "parameter_type.h"
#include "../utilities/list.h"

class ParameterCombo : public ParameterType {
public:
    ParameterCombo(const char **options, int numOptions);
    ParameterCombo(ListInterface<const char*> *options);
    ParameterCombo();
    const char* getType();
    const char* getMinValue();
    const char* getMaxValue();
    const char* getOptions();
    void addOption(const char *option);
protected:
    ListInterface<const char*> *options;
};

#endif
