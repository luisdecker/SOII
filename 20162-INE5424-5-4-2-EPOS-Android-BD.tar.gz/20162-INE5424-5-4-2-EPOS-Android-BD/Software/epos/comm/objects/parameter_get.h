#ifndef PARAMETER_GET_H
#define PARAMETER_GET_H

#include "parameter_type.h"
class ParameterGet : public ParameterType {
public:
    const char* getType();
    const char* getMinValue();
    const char* getMaxValue();
    const char* getOptions();
};

#endif
