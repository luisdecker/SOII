#ifndef SMART_OBJECT_H
#define SMART_OBJECT_H

#include "../utilities/list.h"
#include "service.h"

class SmartObject {
public:
    SmartObject(const char *name);

    /** Getters */
    const char* getName();
    const ListInterface<Service*>* getServices();

    /** Setters */
    void setName(const char *name);
    void addService(Service *service);

    /** Dumper **/
    const char* toString();
protected:
    const char* name;
    ListInterface<Service*> *services;
};

#endif
