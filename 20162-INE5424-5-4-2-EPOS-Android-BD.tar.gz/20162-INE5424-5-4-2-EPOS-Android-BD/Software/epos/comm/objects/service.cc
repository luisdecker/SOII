#ifndef SERVICE_CC
#define SERVICE_CC

#include "service.h"
#include "parameter.cc"
#include "../utilities/list_app.cc"

Service::Service(const char *name) {
    this->name = name;
    this->parameters = new ListApp<Parameter*>();
}

const char* Service::getName() {
    return this->name;
}

const ListInterface<Parameter*>* Service::getParameters() {
    return this->parameters;
}

void Service::setName(const char* name) {
    this->name = name;
}

void Service::addParameter(Parameter* parameter) {
    this->parameters->insert(parameter);
}


const char* Service::toString() {
    int length = 8;
    char *result = new char[length];
    memset(result, '\0', length);
    int c = 0;

    const char *s = this->name;
    int i = c;
    int l = strlen(s);
    c = c+l;
    if (length < c) {
        int c2 = c + 2;
        char *r = new char[c2];
        memset(r, '\0', c2);
        if (length > 0) {
            strcpy(r, result);
            delete[] result;
        }
        result = r;
        length = c2;
    }
    char *r2 = new char[length + 2];
    memset(r2, '\0', length);
    strncpy(r2, result, length);
    strncpy(&r2[i], s, l);
    strncpy(&r2[c], ";", 1);
    c++;
    delete[] result;
    result = r2;

    ListInterface<Parameter*>::Iterator *it = this->parameters->iterator();

    for(; it->hasNext(); it->next()) {
        const char *s = it->element()->toString();
        int i = c;
        int l = strlen(s);
        c = c+l;
        if (length < c) {
            int c2 = c + 1;
            char *r = new char[c2];
            memset(r, '\0', c2);
            if (length > 0) {
                strcpy(r, result);
                delete[] result;
            }
            result = r;
            length = c2;
        }
        char *r2 = new char[length + 2];
        memset(r2, '\0', length+2);
        strncpy(r2, result, length);
        strncpy(&r2[i], s, l);
        delete[] result;
        result = r2;
    }
    return result;
}

#endif
