#ifndef PARAMETER_BOOLEAN_H
#define PARAMETER_BOOLEAN_H

#include "parameter_type.h"
class ParameterBoolean : public ParameterType {
public:
    const char* getType();
    const char* getMinValue();
    const char* getMaxValue();
    const char* getOptions();
};

#endif
