#ifndef PARAMETER_TYPE_H
#define PARAMETER_TYPE_H

class ParameterType {
public:
    virtual const char* getType() = 0;
    virtual const char* getMinValue() = 0;
    virtual const char* getMaxValue() = 0;
    virtual const char* getOptions() = 0;
};

#endif
