#ifndef PARAMETER_BOOLEAN_CC
#define PARAMETER_BOOLEAN_CC

#include "parameter_boolean.h"

const char* ParameterBoolean::getType() {
    return "boolean";
}

const char* ParameterBoolean::getMinValue() {
    return "";
}

const char* ParameterBoolean::getMaxValue() {
    return "";
}

const char* ParameterBoolean::getOptions() {
    return "";
}

#endif
