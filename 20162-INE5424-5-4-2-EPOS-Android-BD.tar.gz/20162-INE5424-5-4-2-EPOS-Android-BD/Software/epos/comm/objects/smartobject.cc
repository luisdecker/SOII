#ifndef SMART_OBJECT_CC
#define SMART_OBJECT_CC

#include "smartobject.h"
#include "service.cc"
#include "../utilities/list_app.cc"

SmartObject::SmartObject(const char *name) {
    this->name = name;
    this->services = new ListApp<Service*>();
}

const char* SmartObject::getName() {
    return this->name;
}

const ListInterface<Service*>* SmartObject::getServices() {
    return this->services;
}

void SmartObject::setName(const char* name) {
    this->name = name;
}

void SmartObject::addService(Service* service) {
    this->services->insert(service);
}

const char* SmartObject::toString() {
    int length = 8;
    char *result = new char[length];
    memset(result, '\0', length);
    int c = 0;

    const char *s = this->name;
    int i = c;
    int l = strlen(s);
    c = c+l;
    if (length < c) {
        int c2 = c + 1;
        char *r = new char[c2];
        memset(r, '\0', c2);
        if (length > 0) {
            strcpy(r, result);
            delete[] result;
        }
        result = r;
        length = c2;
    }
    char *r2 = new char[length + 2];
    memset(r2, '\0', length+2);
    strncpy(r2, result, length);
    strncpy(&r2[i], s, l);
    strncpy(&r2[c], ";", 1);
    c++;
    delete[] result;
    result = r2;

    ListInterface<Service*>::Iterator *it;

    for(it=this->services->iterator(); it->hasNext(); it->next()) {
        const char *s = it->element()->toString();
        int i = c;
        int l = strlen(s);
        c = c+l;
        if (length < c) {
            int c2 = c + 1;
            char *r = new char[c2];
            memset(r, '\0', c2);
            if (length > 0) {
                strcpy(r, result);
                delete[] result;
            }
            result = r;
            length = c2;
        }
        char *r2 = new char[length + 2];
        memset(r2, '\0', length+2);
        strncpy(r2, result, length);
        strncpy(&r2[i], s, l);
        delete[] result;
        result = r2;
    }
    return result;
}
#endif
