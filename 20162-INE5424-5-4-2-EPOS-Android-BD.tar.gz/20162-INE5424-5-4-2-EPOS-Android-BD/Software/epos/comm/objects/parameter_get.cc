#ifndef PARAMETER_GET_CC
#define PARAMETER_GET_CC

#include "parameter_get.h"

const char* ParameterGet::getType() {
    return "get";
}

const char* ParameterGet::getMinValue() {
    return "";
}

const char* ParameterGet::getMaxValue() {
    return "";
}

const char* ParameterGet::getOptions() {
    return "";
}

#endif
