#ifndef PARAMETER_H
#define PARAMETER_H

#include "parameter_type.h"

class Parameter {
public:
    Parameter(const char* name, const char* registerId, ParameterType *type);
    /** Getters */
    const char* getName();
    const char* getRegisterId();
    const char* getType();
    const char* getMinValue();
    const char* getMaxValue();
    const char* getOptions();

    /** Setters */
    void setName(const char *name);
    void setRegisterId(int registerId);
    void setType(ParameterType *type);

    /** Dumper **/
    const char* toString();
protected:
    const char* name;
    const char* registerId;
    ParameterType *type;
};

#endif
