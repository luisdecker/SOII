#ifndef PARAMETER_COMBO_CC
#define PARAMETER_COMBO_CC

#include "parameter_combo.h"
#include "../utilities/list.h"
#include "../utilities/list_app.cc"
#ifdef SIMULATE
#include <string.h>
#else
#include <utility/string.h>
#endif

ParameterCombo::ParameterCombo(const char **options, int numOptions) {
    this->options = new ListApp<const char*>();
    for(int c=0; c<numOptions; c++) {
        this->options->insert(options[c]);
    }
}

ParameterCombo::ParameterCombo(ListInterface<const char*> *options) {
    this->options = options;
}

ParameterCombo::ParameterCombo() {
    this->options = new ListApp<const char*>();
}

const char* ParameterCombo::getType() {
    return "combo";
}

const char* ParameterCombo::getMinValue() {
    return "";
}

const char* ParameterCombo::getMaxValue() {
    return "";
}

const char* ParameterCombo::getOptions() {
    int length = 8;
    char *result = new char[length];
    memset(result, '\0', length);
    int c = 0;
    ListInterface<const char*>::Iterator *it;
    for(it=this->options->iterator(); it->hasNext(); it->next()) {
        const char *s = it->element();
        int i = c;
        int l = strlen(s);
        c = c+l;
        if (length < c) {
            int c2 = c + 1;
            char *r = new char[c2];
            memset(r, '\0', c2);
            if (length > 0) {
                strcpy(r, result);
                delete[] result;
            }
            result = r;
            length = c2;
        }
        char *r2 = new char[length + 2];
        memset(r2, '\0', length);
        strncpy(r2, result, length);
        strncpy(&r2[i], s, l);
        strncpy(&r2[c], "|", 1);
        c++;
        delete[] result;
        result = r2;
    }
    result[c-1] = '\0';
    return result;
}

void ParameterCombo::addOption(const char *option) {
    this->options->insert(option);
}
#endif
