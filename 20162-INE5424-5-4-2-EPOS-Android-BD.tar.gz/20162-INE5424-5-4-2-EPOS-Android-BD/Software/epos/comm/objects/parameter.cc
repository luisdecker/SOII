#ifndef PARAMETER_CC
#define PARAMETER_CC

#include "parameter.h"
#include "parameter_type.h"

Parameter::Parameter(const char* name, const char* registerId, ParameterType *type) {
    this->name = name;
    this->registerId = registerId;
    this->type = type;
}

const char* Parameter::getName() {
    return this->name;
}

const char* Parameter::getRegisterId() {
    return this->registerId;
}

const char* Parameter::getType() {
    return this->type->getType();
}

const char* Parameter::getMinValue() {
    return this->type->getMinValue();
}

const char* Parameter::getMaxValue() {
    return this->type->getMaxValue();
}

const char* Parameter::getOptions() {
    return this->type->getOptions();
}

const char* Parameter::toString() {
    int length = 8;
    char *result = new char[length];
    memset(result, '\0', length);
    int c = 0;

    const char* ss[6];
    ss[0] = this->name;
    ss[1] = this->registerId;
    ss[2] = this->getType();
    ss[3] = this->getMinValue();
    ss[4] = this->getMaxValue();
    ss[5] = this->getOptions();

    for(int counter=0; counter < 6; counter++) {
        const char *s = ss[counter];
        int i = c;
        int l = strlen(s);
        c = c+l;
        if (length < c) {
            int c2 = c + 1;
            char *r = new char[c2];
            memset(r, '\0', c2);
            if (length > 0) {
                strcpy(r, result);
                delete[] result;
            }
            result = r;
            length = c2;
        }
        char *r2 = new char[length + 2];
        memset(r2, '\0', length+2);
        strncpy(r2, result, length);
        strncpy(&r2[i], s, l);
        strncpy(&r2[c], ",", 1);
        c++;
        delete[] result;
        result = r2;
    }
    strncpy(&result[c-1], ";", 1);
    return result;
}

#endif
