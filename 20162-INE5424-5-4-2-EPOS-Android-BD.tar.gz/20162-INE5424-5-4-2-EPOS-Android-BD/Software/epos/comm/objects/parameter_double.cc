#ifndef PARAMETER_DOUBLE_CC
#define PARAMETER_DOUBLE_CC

#include "parameter_double.h"

ParameterDouble::ParameterDouble(const char* min, const char* max) {
    this->min = min;
    this->max = max;
}
const char* ParameterDouble::getType() {
    return "double";
}

const char* ParameterDouble::getMinValue() {
    return this->min;
}

const char* ParameterDouble::getMaxValue() {
    return this->max;
}

const char* ParameterDouble::getOptions() {
    return "";
}

#endif
