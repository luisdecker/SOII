#ifndef MODBUSMANAGER_CC
#define MODBUSMANAGER_CC
#include "modbus_manager.h"
#include "communication.h"
#include "message_factory.h"
#include "serialization/message.cc"
#include "../events/read_register.h"
#include "../events/write_register.h"
#include "../events/wrapper_read_register.cc"
#include "../events/wrapper_write_register.cc"
#include "../events/ack/ack_read.h"
#include "../events/ack/ack_write.h"
#include "../events/ack/ack_read_error.cc"
#include "../events/ack/ack_write_error.cc"
#include "../utilities/list_app.cc"

ModbusManager::ModbusManager(Communication *comm, MessageFactory *msg_factory) {
    this->comm = comm;
    this->msg_factory = msg_factory;
    this->listRead = new ListApp<ReadRegisterInterface*>();
    this->listWrite = new ListApp<WriteRegisterInterface*>();
}

ModbusManager::~ModbusManager() {
    delete this->listRead;
    delete this->listWrite;
}


void ModbusManager::setReadHandler(AckRead* (*fptr)(int)) {
    this->setReadHandler(new WrapperReadRegister(fptr));
}
void ModbusManager::setReadHandler(ReadRegisterInterface *fptr) {
    this->listRead->insert(fptr);

}
void ModbusManager::setWriteHandler(AckWrite* (*fptr)(int, int)) {
    this->setWriteHandler(new WrapperWriteRegister(fptr));
}
void ModbusManager::setWriteHandler(WriteRegisterInterface *fptr) {
    this->listWrite->insert(fptr);
}

int ModbusManager::writeRegister(int address, int reg, int value) {
    Message *msg = this->msg_factory->writeRegister(address, reg, value);
    Message *ack = this->comm->send(msg);
    int successCount = 0;
    int funCode = Message::fromHex(msg->getFunctionCode());
    if (ack != 0 && funCode == Message::fromHex(ack->getFunctionCode())) {
        successCount++;
    }
    return successCount;
}

int ModbusManager::getAddress() {
    return this->comm->getAddress();
}

void ModbusManager::run() {
    while (true) {
        Message *msg = comm->receive();
        int function = Message::fromHex(msg->getFunctionCode());
        Message *msgAck;
        if (function == int(MessageType::READ_HOLDING_REGISTERS)) {
            int startingAddress = Message::fromHex(msg->getDataSlice(0, 4));
            int quantity = Message::fromHex(msg->getDataSlice(4, 8));
            ListInterface<ReadRegisterInterface*> *readRegisters = this->listRead;
            AckRead **acks = new AckRead*[quantity + 2];
            int count = 0;
            for (int address = startingAddress, l = startingAddress + quantity;
                    address < l; address++) {
                AckRead *ack = 0;
                ListInterface<ReadRegisterInterface*>::Iterator *it = 0;
                for (it=readRegisters->iterator(); it->hasNext(); it->next()) {
                    ack = it->element()->read(address);
                    if (ack != 0) {
                        break;
                    }
                }
                if (it != 0) {
                    delete it;
                }
                if (ack == 0) {
                    ack = new AckReadError(AckReadErrorType::ILLEGAL_ADDRESS);
                }
                acks[count] = ack;
                count++;
            }
            msgAck = msg_factory->fromAckRead(msg, acks, count);
        } else if (function == int(MessageType::WRITE_SINGLE_REGISTER) ||
                    function == int(MessageType::WRITE_MULTIPLE_REGISTERS))  {
            int startingAddress = Message::fromHex(msg->getDataSlice(0, 4));
            int quantity = 1;
            int dataStart = 4;
            int count = 0;
            int functionCode = Message::fromHex(msg->getFunctionCode());
            AckWrite **acks;
            ListInterface<WriteRegisterInterface*> *writeRegisters = this->listWrite;
            if (functionCode == int(MessageType::WRITE_MULTIPLE_REGISTERS)) {
                quantity = Message::fromHex(msg->getDataSlice(4, 8));
                acks = new AckWrite*[quantity+1];
                int byteCount = Message::fromHex(msg->getDataSlice(8, 10));
                if (byteCount != quantity * 2) {
                    // Add error related to acks error data
                    acks[count] = new AckWriteError(AckWriteErrorType::ILLEGAL_DATA);
                    count++;
                }
                // set new data start location..
                dataStart = 10;
            } else {
                acks = new AckWrite*[quantity];
            }
            for (int address = startingAddress, l = startingAddress + quantity;
                    address < l; address++) {
                AckWrite *ack = 0;
                int value =
                    Message::fromHex(msg->getDataSlice(dataStart, dataStart + 4));
                dataStart += 4;
                ListInterface<WriteRegisterInterface*>::Iterator *it = 0;
                for(it = writeRegisters->iterator(); it->hasNext(); it->next()) {
                    ack = it->element()->write(address, value);
                    if (ack != 0) {
                        break;
                    }
                }
                if (ack == 0) {
                    ack = new AckWriteError(AckWriteErrorType::ILLEGAL_ADDRESS);
                }
                acks[count] = ack;
                count++;
            }
            msgAck = msg_factory->fromAckWrite(msg, acks, count);
        }
        this->comm->ack(msgAck);
    }
}

#endif
