#ifndef MESSAGEFACTORY_CC
#define MESSAGEFACTORY_CC

#include "message_factory.h"
#include "serialization/message_type.h"
#include "serialization/message.h"

#include "../events/ack/ack_read.h"
#include "../events/ack/ack_write.h"
#include "../events/ack/ack_read_error.cc"
#include "../events/ack/ack_write_error.cc"
#include "../events/ack/ack_read_error_type.h"
#include "../events/ack/ack_write_error_type.h"
#include "../events/ack/ack_read_success.cc"
#include "../events/ack/ack_write_success.cc"

#ifndef SIMULATE
#include <utility/string.h>
#else
#include <cstring>
#endif

MessageFactory::MessageFactory() {}

MessageFactory::~MessageFactory() {}
Message* MessageFactory::fromAck(Message *orig) {
    Message *result = new Message();
    result->setAddress(orig->getAddress());
    return result;
}
Message* MessageFactory::writeRegister(int address, int reg, int value) {
    Message *msg = new Message();
    msg->setAddress(address);
    msg->setFunctionCode(MessageType::WRITE_SINGLE_REGISTER);
    msg->setDataSlice(reg, 0, 4);
    msg->setDataSlice(value, 4, 8);
    return msg;
}
// Worth it?
Message* MessageFactory::writeRegister(int address, int startingRegister,
                                       int value[], int valueSize) {
    Message *msg = new Message();
    msg->setAddress(address);
    msg->setFunctionCode(MessageType::WRITE_MULTIPLE_REGISTERS);
    msg->setDataSlice(startingRegister, 0, 4);
    msg->setDataSlice(valueSize, 4, 8);
    msg->setDataSlice(valueSize * 2, 8, 10);
    for (int c = 0, start = 10, l = valueSize; c < l; c++) {
        msg->setDataSlice(value[c], start, start + 4);
        start += 4;
    }
    return msg;
}
Message* MessageFactory::readRegister(int address, int reg, int registerCount) {
    Message *msg = new Message();
    msg->setAddress(address);
    msg->setFunctionCode(MessageType::READ_HOLDING_REGISTERS);
    msg->setDataSlice(reg, 0, 4);
    msg->setDataSlice(registerCount, 4, 8);
    return msg;
}
Message* MessageFactory::fromAckRead(Message *orig, AckRead **acks,
                                     int ackSize) {
    Message *result = this->fromAck(orig);
    int funCode = Message::fromHex(orig->getFunctionCode());
    result->setFunctionCode(funCode);
    bool isError = false;
    for (int i = 0; i < ackSize; i++) {
        if (acks[i]->getType() == 'E') {
            AckReadError *ackErr = static_cast<AckReadError *>(acks[i]);
            result->setFunctionCode(funCode + 128);
            isError = true;
            int readErrorCode = 7;
            switch (ackErr->getErrorType()) {
                case AckReadErrorType::ILLEGAL_ADDRESS:
                    readErrorCode = 2;
                    break;
                case AckReadErrorType::ILLEGAL_FUNCTION:
                    readErrorCode = 1;
                    break;
                case AckReadErrorType::ILLEGAL_DATA:
                    readErrorCode = 3;
                    break;
                case AckReadErrorType::NEGATIVE_ACK:
                    readErrorCode = 7;
                    break;
                case AckReadErrorType::BUSY:
                    readErrorCode = 6;
                    break;
                case AckReadErrorType::FAILURE:
                    readErrorCode = 4;
                    break;
            }
            result->setDataSlice(readErrorCode, 0, 1);
            break;
        }
    }
    if (!isError) {           // Check if there is no errors
        result->setDataSlice(ackSize * 2, 0, 2); // Byte count
        int start = 2;
        for (int i = 0; i < ackSize; i++) {
            result->setDataSlice((static_cast<AckReadSuccess*>(acks[i]))->getData(),
                                 start, start + 4);
            start += 4;
        }
    }
    return result;
}
Message* MessageFactory::fromAckWrite(Message *orig, AckWrite **acks,
                                      int ackSize) {
    Message *result = this->fromAck(orig);
    int funCode = Message::fromHex(orig->getFunctionCode());
    result->setFunctionCode(funCode);
    bool isError = false;
    for (int i = 0; i < ackSize; i++) {
        if (acks[i]->getType() == 'E') {
            AckWriteError *ackErr = static_cast<AckWriteError*>(acks[i]);
            result->setFunctionCode(funCode + 128);
            isError = true;
            int writeErrorCode = 7;
            switch (ackErr->getErrorType()) {
                case AckWriteErrorType::ILLEGAL_ADDRESS:
                    writeErrorCode = 2;
                    break;
                case AckWriteErrorType::ILLEGAL_FUNCTION:
                    writeErrorCode = 1;
                    break;
                case AckWriteErrorType::ILLEGAL_DATA:
                    writeErrorCode = 3;
                    break;
                case AckWriteErrorType::NEGATIVE_ACK:
                    writeErrorCode = 7;
                    break;
                case AckWriteErrorType::BUSY:
                    writeErrorCode = 6;
                    break;
                case AckWriteErrorType::FAILURE:
                    writeErrorCode = 4;
                    break;
            }
            result->setDataSlice(writeErrorCode, 0, 1);
            break;
        }
    }
    if (!isError) { // Check if there is no errors
        if (ackSize == 1) {
            const char* data = orig->getData();
            result->setDataSlice(data, 0, strlen(data));
        } else {
            result->setDataSlice(orig->getDataSlice(0, 8), 0, 8);
        }
    }
    return result;
}

#endif
