#ifndef MESSAGEFACTORY_H
#define MESSAGEFACTORY_H
#include "serialization/message.h"
#include "../events/ack/ack_read.h"
#include "../events/ack/ack_write.h"
class MessageFactory {
private:
    Message *fromAck(Message *orig);

public:
    MessageFactory();
    ~MessageFactory();
    Message* writeRegister(int address, int reg, int value);
    // Worth it?
    Message* writeRegister(int address, int startingRegister, int value[],
                           int valueSize);
    Message* readRegister(int address, int reg, int registerCount);
    Message* fromAckRead(Message *orig, AckRead **acks, int ackSize);
    Message* fromAckWrite(Message *orig, AckWrite **acks, int ackSize);
};
#endif
