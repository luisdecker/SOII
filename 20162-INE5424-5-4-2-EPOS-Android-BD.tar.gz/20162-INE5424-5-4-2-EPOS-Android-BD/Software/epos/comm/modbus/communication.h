#ifndef COMMUNICATION_H
#define COMMUNICATION_H

#include "../utilities/condition.h"
#include "../utilities/list.h"
#include "../utilities/mutex.h"
#include "../utilities/queue.h"
#include "serialization/serialization.h"
#include "serialization/message.h"
#include "../transport/transport.h"

class Communication {
public:
    Communication(int address, TransportInterface *transport,
                  Serialization *serialization);
    Message *send(Message *message, int retry = 1);
    bool ack(Message *message);
    int getAddress();
    Message *receive();
    void run();
    void runGC();

protected:
    int address;
    TransportInterface *transport;
    Serialization *serialization;
    MutexInterface *mutexQueue;
    MutexInterface *mutexSend;
    ListInterface<int> *sent;
    QueueInterface<Message*> *receiveSendQueue;
    QueueInterface<Message*> *receiveQueue;
    ConditionInterface *notifierSend;
    ConditionInterface *notifier;
};

#endif
