#ifndef MODBUSMANAGER_H
#define MODBUSMANAGER_H
#include "../protocol_manager.h"
#include "../utilities/list.h"
#include "../events/read_register.h"
#include "../events/write_register.h"
#include "../events/ack/ack_read.h"
#include "../events/ack/ack_write.h"
#include "communication.h"
#include "message_factory.h"

class ModbusManager : public ProtocolManager {
public:
    ModbusManager(Communication *comm, MessageFactory *msg_factory);
    ~ModbusManager();
    void setReadHandler(AckRead* (*fptr)(int));
    void setReadHandler(ReadRegisterInterface *fptr);
    void setWriteHandler(AckWrite* (*fptr)(int, int));
    void setWriteHandler(WriteRegisterInterface *fptr);
    int writeRegister(int address, int reg, int value);
    int getAddress();
    void run();

private:
    Communication *comm;
    MessageFactory *msg_factory;
    ListInterface<ReadRegisterInterface*> *listRead;
    ListInterface<WriteRegisterInterface*> *listWrite;
};
#endif
