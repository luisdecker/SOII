#ifndef MODBUS_FACTORY_CC
#define MODBUS_FACTORY_CC

#include "modbus_factory.h"
#include "../protocol_manager.h"
#include "../transport/transport.h"
#include "serialization/serialization.cc"
#include "communication.cc"
#include "message_factory.cc"
#include "modbus_manager.cc"

Communication* ModbusFactory::buildCommunication(int address, TransportInterface *transport) {
    Serialization *s = new Serialization();
    return new Communication(address, transport, s);
}

ProtocolManager* ModbusFactory::build(Communication *c) {
    MessageFactory *f = new MessageFactory();
    return new ModbusManager(c, f);
}

#endif
