#ifndef MODBUS_FACTORY_H
#define MODBUS_FACTORY_H

#include "../protocol_manager.h"
#include "../transport/transport.h"
#include "communication.h"

class ModbusFactory {
public:
    static Communication* buildCommunication(int address, TransportInterface *transport);
    static ProtocolManager* build(Communication *c);
};

#endif
