#ifndef WRAPPER_READ_REGISTER_CC
#define WRAPPER_READ_REGISTER_CC
#include "wrapper_read_register.h"

WrapperReadRegister::WrapperReadRegister(AckRead* (*fptr)(int)) {
    this->func = fptr;
}

AckRead* WrapperReadRegister::read(int address) {
   AckRead* (*fptr)(int) = this->func;
   return fptr(address);
}

#endif
