#ifndef WRITEREGISTERLISTENER_H
#define WRITEREGISTERLISTENER_H

#include "ack/ack_write.h"

class WriteRegisterInterface {
public:
    virtual AckWrite* write(int address, int value) = 0;
};

#endif
