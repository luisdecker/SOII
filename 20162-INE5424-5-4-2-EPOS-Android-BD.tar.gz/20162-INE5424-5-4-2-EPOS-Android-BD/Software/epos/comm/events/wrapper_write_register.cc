#ifndef WRAPPER_WRITE_REGISTER_CC
#define WRAPPER_WRITE_REGISTER_CC

#include "wrapper_write_register.h"

WrapperWriteRegister::WrapperWriteRegister(AckWrite* (*fptr)(int, int)) {
    this->func = fptr;
}

AckWrite* WrapperWriteRegister::write(int address, int value) {
    return this->func(address, value);
}


#endif
