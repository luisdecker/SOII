#ifndef READREGISTERLISTENER_H
#define READREGISTERLISTENER_H
#include "ack/ack_read.h"

class ReadRegisterInterface {
public:
    virtual AckRead* read(int address) = 0;
};
#endif
