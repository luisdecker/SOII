#ifndef WRAPPER_WRITE_REGISTER_H
#define WRAPPER_WRITE_REGISTER_H

#include "write_register.h"

class WrapperWriteRegister : public WriteRegisterInterface {
    typedef AckWrite* (*fW)(int, int);
private:
    fW func;

public:
    WrapperWriteRegister(AckWrite* (*fptr)(int, int));
    AckWrite* write(int address, int value);
};


#endif
