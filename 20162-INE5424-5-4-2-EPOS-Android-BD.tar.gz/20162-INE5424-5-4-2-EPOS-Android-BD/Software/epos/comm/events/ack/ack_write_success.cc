#ifndef ACKWRITESUCCESS_CC
#define ACKWRITESUCCESS_CC
#include "ack_write_success.h"

AckWriteSuccess::AckWriteSuccess() {}

const char AckWriteSuccess::getType() {
    return 'S';
}

#endif
