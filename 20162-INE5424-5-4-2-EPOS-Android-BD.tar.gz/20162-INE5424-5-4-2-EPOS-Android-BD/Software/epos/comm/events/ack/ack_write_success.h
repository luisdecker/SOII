#ifndef ACKWRITESUCCESS_H
#define ACKWRITESUCCESS_H

#include "ack_write.h"

class AckWriteSuccess : public AckWrite {
private:
    int data;

public:
    AckWriteSuccess();
    const char getType();
};
#endif
