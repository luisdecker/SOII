#ifndef ACKREADSUCCESS_CC
#define ACKREADSUCCESS_CC

#include "ack_read_success.h"

AckReadSuccess::AckReadSuccess(int data) {
    this->data = data;
}


const char AckReadSuccess::getType() {
    return 'S';
}

const int AckReadSuccess::getData() {
    return this->data;
}

#endif
