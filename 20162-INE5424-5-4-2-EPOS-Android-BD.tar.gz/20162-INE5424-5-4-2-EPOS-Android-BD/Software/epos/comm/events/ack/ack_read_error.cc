#ifndef ACKREADERROR_CC
#define ACKREADERROR_CC
#include "ack_read_error.h"
#include "ack_read_error_type.h"

AckReadError::AckReadError(AckReadErrorType type) {
    this->type = type;
}

const char AckReadError::getType() {
    return 'E';
}

const AckReadErrorType AckReadError::getErrorType() {
    return type;
}

#endif
