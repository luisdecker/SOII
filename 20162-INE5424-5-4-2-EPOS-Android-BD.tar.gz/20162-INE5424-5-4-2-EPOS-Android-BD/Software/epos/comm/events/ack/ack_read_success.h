#ifndef ACKREADSUCCESS_H
#define ACKREADSUCCESS_H

#include "ack_read.h"

class AckReadSuccess : public AckRead {
private:
    int data;

public:
    AckReadSuccess(int data);

    const char getType();
    const int getData();
};

#endif
