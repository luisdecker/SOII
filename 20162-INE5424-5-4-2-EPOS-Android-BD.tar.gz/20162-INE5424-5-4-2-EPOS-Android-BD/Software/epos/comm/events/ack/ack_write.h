#ifndef ACKWRITE_H
#define ACKWRITE_H

class AckWrite {
public:
    virtual const char getType() = 0;
};

#endif
