#ifndef ACKREAD_H
#define ACKREAD_H
class AckRead {
public:
    virtual const char getType() = 0;
};
#endif
