#ifndef ACKREADERROR_H
#define ACKREADERROR_H

#include "ack_read.h"
#include "ack_read_error_type.h"


class AckReadError : public AckRead {
private:
    AckReadErrorType type;

public:
    AckReadError(AckReadErrorType type);

    const char getType();
    const AckReadErrorType getErrorType();
};
#endif
