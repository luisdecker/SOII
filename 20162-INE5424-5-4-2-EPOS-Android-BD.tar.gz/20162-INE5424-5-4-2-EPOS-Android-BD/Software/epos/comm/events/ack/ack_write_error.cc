#ifndef ACKWRITEERROR_CC
#define ACKWRITEERROR_CC
#include "ack_write_error.h"
#include "ack_write_error_type.h"

AckWriteError::AckWriteError(AckWriteErrorType type) {
    this->type = type;
}

const char AckWriteError::getType() {
    return 'E';
}

const AckWriteErrorType AckWriteError::getErrorType() {
    return type;
}

#endif
