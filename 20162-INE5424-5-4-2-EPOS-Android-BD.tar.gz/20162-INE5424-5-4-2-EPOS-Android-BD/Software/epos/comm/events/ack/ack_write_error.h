#ifndef ACKWRITEERROR_H
#define ACKWRITEERROR_H
#include "ack_write.h"
#include "ack_write_error_type.h"

class AckWriteError : public AckWrite {
private:
    AckWriteErrorType type;

public:
    AckWriteError(AckWriteErrorType type);

    const char getType();
    const AckWriteErrorType getErrorType();
};

#endif
