#ifndef WRAPPER_READ_REGISTER_H
#define WRAPPER_READ_REGISTER_H

#include "read_register.h"

class WrapperReadRegister : public ReadRegisterInterface {
    typedef AckRead* (*fR)(int);

private:
    fR func;

public:
    WrapperReadRegister(AckRead* (*fR)(int));
    AckRead* read(int address);
};

#endif
