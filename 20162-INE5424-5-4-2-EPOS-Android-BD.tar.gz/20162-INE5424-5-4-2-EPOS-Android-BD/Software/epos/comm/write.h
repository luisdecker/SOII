#ifndef WRITE_H
#define WRITE_H

class WriteInterface {
public:
    virtual bool write(int val) = 0;
};

#endif
