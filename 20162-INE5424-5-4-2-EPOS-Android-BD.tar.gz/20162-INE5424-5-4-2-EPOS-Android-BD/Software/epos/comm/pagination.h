#ifndef PAGINATION_H
#define PAGINATION_H

#include "events/read_register.h"
#include "events/write_register.h"
#include "events/ack/ack_write.h"
#include "events/ack/ack_read.h"
#include "pagination.h"

class Pagination : public ReadRegisterInterface, public WriteRegisterInterface {
public:
    Pagination(const char* data, int startingRegister, int pageSize);
    AckRead* read(int address);
    AckWrite* write(int address, int value);

protected:
    int startingRegister;
    int page;
    int pageSize;
    int dataLength;
    const char* data;
};

#endif
