#ifndef WRAPPER_WRITE_CC
#define WRAPPER_WRITE_CC

#include "wrapper_write.h"

WrapperWrite::WrapperWrite(bool (*fptr)(int)) {
    this->func = fptr;
}

bool WrapperWrite::write(int val) {
    return this->func(val);
}


#endif
