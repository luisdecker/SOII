#ifndef PAGINATION_CC
#define PAGINATION_CC

#include "pagination.h"
#include "events/ack/ack_write_success.cc"
#include "events/ack/ack_read_success.cc"
#include "events/ack/ack_read_error.cc"
#include "events/ack/ack_read_error_type.h"
#ifdef SIMULATE
#include <string.h>
#else
#include <utility/string.h>
#endif

Pagination::Pagination(const char* data, int startingRegister, int pageSize) {
    this->data = data;
    this->dataLength = strlen(data);

    this->startingRegister = startingRegister;
    this->pageSize = pageSize-1;
    this->page = 0;
}

AckRead* Pagination::read(int address) {
    if (this->startingRegister > address || (this->startingRegister+this->pageSize) < address) {
        // Not in the interval, just ignore it..
        return 0;
    }
    if (this->startingRegister == address) {
        // Return the actual page if it is the starting register..
        return new AckReadSuccess(this->page);
    }
    int baseOffset = (address-this->startingRegister-1) % this->pageSize;
    int offset = (this->page * this->pageSize) + baseOffset;
    if (offset > this->dataLength) {

        return new AckReadSuccess('\0'); // Null char
    }
    return new AckReadSuccess(this->data[offset]);
}

AckWrite* Pagination::write(int address, int value) {
    if (this->startingRegister > address && (this->startingRegister+this->pageSize) <= address) {
        // Only manages writes to the startingRegister.., but return error if inside the
        // interval between startingRegister and startingRegister+pageSize
        return new AckWriteError(AckWriteErrorType::ILLEGAL_ADDRESS);
    }
    if (this->startingRegister != address) {
        // If it is not inside the interval and we do not know anything about
        // that address, just return a null pointer...
        return 0;
    }
    this->page = value;
    return new AckWriteSuccess();

}

#endif
