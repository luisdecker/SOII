#ifndef PROTOCOLMANAGER_H
#define PROTOCOLMANAGER_H
#include "events/read_register.h"
#include "events/write_register.h"
#include "events/ack/ack_read.h"
#include "events/ack/ack_write.h"
#include "utilities/function.h"

class ProtocolManager {
public:
    virtual void setReadHandler(AckRead* (*fptr)(int)) = 0;
    virtual void setReadHandler(ReadRegisterInterface *fptr) = 0;
    virtual void setWriteHandler(AckWrite* (*fptr)(int, int)) = 0;
    virtual void setWriteHandler(WriteRegisterInterface *fptr) = 0;
    virtual int writeRegister(int address, int reg, int value) = 0;
    virtual int getAddress() = 0;
    virtual void run() = 0;
};
#endif
