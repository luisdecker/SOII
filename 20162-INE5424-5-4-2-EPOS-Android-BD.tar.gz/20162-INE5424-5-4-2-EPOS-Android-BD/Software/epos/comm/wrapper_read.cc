#ifndef WRAPPER_READ_CC
#define WRAPPER_READ_CC
#include "wrapper_read.h"

WrapperRead::WrapperRead(int (*fptr)()) {
    this->func = fptr;
}

int WrapperRead::read() {
   int (*fptr)() = this->func;
   return fptr();
}

#endif
