/**
 *
 */
package br.com.mobgui4so.model.discovery;

import br.com.mobgui4so.model.pojo.SmartObjectList;

/**
 * @author Ercilio Nascimento
 */
public class BluetoothSmartObjectDiscovery extends BaseSmartObjectDiscovery {

    @Override
    public SmartObjectList execute(String[] form) {
        // TODO
        return null;
    }

}
