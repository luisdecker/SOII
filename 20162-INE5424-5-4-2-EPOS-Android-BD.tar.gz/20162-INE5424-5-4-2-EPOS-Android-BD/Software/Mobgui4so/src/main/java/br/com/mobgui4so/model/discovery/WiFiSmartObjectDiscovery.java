/**
 *
 */
package br.com.mobgui4so.model.discovery;

import br.com.mobgui4so.model.interaction.SmartObjectListRequester;
import br.com.mobgui4so.model.pojo.SmartObjectList;

import java.io.IOException;

/**
 * @author Ercilio Nascimento
 */
public class WiFiSmartObjectDiscovery extends BaseSmartObjectDiscovery {

    @Override
    public SmartObjectList execute(String[] form) throws IOException {
        return SmartObjectListRequester.getSmartObjectList(form);
    }

}
