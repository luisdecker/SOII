/**
 *
 */
package br.com.mobgui4so.model.discovery;

import br.com.mobgui4so.model.pojo.SmartObjectList;

import java.io.IOException;

/**
 * @author Ercilio Nascimento
 */
public abstract class BaseSmartObjectDiscovery {

    public abstract SmartObjectList execute(String[] form) throws IOException;

}
