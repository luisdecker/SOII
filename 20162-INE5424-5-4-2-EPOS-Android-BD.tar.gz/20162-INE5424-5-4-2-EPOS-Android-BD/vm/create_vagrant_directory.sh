sudo mkdir /vagrant
sudo chmod -Rvf 0777 /vagrant

